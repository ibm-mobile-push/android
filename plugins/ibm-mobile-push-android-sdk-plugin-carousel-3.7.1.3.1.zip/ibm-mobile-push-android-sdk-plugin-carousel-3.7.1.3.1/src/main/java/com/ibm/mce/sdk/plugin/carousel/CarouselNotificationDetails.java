/*
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2019.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.carousel;

import com.ibm.mce.sdk.api.notification.Action;
import com.ibm.mce.sdk.api.notification.Expandable;
import com.ibm.mce.sdk.api.notification.MceNotificationPayload;
import com.ibm.mce.sdk.api.notification.NotificationDetails;
import com.ibm.mce.sdk.util.property.Property;

import java.util.Arrays;

public class CarouselNotificationDetails implements NotificationDetails {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2019, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    @Property
    private String subject;
    @Property
    private String message;
    @Property
    private String notificationUUID;
    @Property
    private int carouselIndex;
    @Property
    private String payload;
    @Property
    private String group;
    @Property
    private String attribution;
    @Property
    private String mailingId;
    @Property
    private boolean sensitive;
    @Property
    private boolean highPriority;
    @Property
    private boolean soundEnabled;
    @Property
    private int soundResourceId;
    @Property
    private boolean vibrateEnabled;
    @Property
    private long[] vibratePattern;
    @Property
    private boolean lightsEnabled;
    @Property
    private int[] lights;
    @Property
    private int number;

    private MceNotificationPayload mceNotificationPayload;

    public CarouselNotificationDetails() {
    }

    public CarouselNotificationDetails(NotificationDetails notificationDetails, String notificationUUID, int carouselIndex) {
        this.subject = notificationDetails.getSubject();
        this.message = notificationDetails.getMessage();
        this.notificationUUID = notificationUUID;
        this.carouselIndex = carouselIndex;
        this.payload = notificationDetails.getPayload();
        this.group = notificationDetails.getMceNotificationPayload().getGroup();
        this.attribution = notificationDetails.getMceNotificationPayload().getAttribution();
        this.mailingId = notificationDetails.getMceNotificationPayload().getMailingId();
        this.sensitive = notificationDetails.isSensitive();
        this.highPriority = notificationDetails.isHighPriority();
        this.soundEnabled = notificationDetails.isSoundEnabled();
        this.soundResourceId = notificationDetails.getSoundResourceId();
        this.vibrateEnabled = notificationDetails.isVibrateEnabled();
        this.vibratePattern = notificationDetails.getVibratePattern();
        this.lightsEnabled = notificationDetails.isLightsEnabled();
        this.lights = notificationDetails.getLights();
        this.number = notificationDetails.getNumber();
    }

    public String getSubject() {
        return subject;
    }

    public String getMessage() {
        return message;
    }

    public String getNotificationUUID() {
        return notificationUUID;
    }

    public int getCarouselIndex() {
        return carouselIndex;
    }

    public String getPayload() {
        return payload;
    }

    public String getGroup() {
        return group;
    }

    public String getAttribution() {
        return attribution;
    }

    @Override
    public String getType() {
        return null;
    }


    @Override
    public Action getAction() {
        return null;
    }

    @Override
    public String getIconUrl() {
        return null;
    }

    @Override
    public Expandable getExpandable() {
        return null;
    }

    @Override
    public MceNotificationPayload getMceNotificationPayload() {
        if(mceNotificationPayload == null) {
            mceNotificationPayload = new MceNotificationPayload() {
                @Override
                public String getAttribution() {
                    return attribution;
                }

                @Override
                public String getMailingId() {
                    return mailingId;
                }

                @Override
                public String getGroup() {
                    return group;
                }
            };
        }
        return mceNotificationPayload;
    }

    @Override
    public boolean isSensitive() {
        return sensitive;
    }

    @Override
    public boolean isHighPriority() {
        return highPriority;
    }

    @Override
    public boolean isSoundEnabled() {
        return soundEnabled;
    }

    @Override
    public Integer getSoundResourceId() {
        return soundResourceId;
    }

    @Override
    public boolean isVibrateEnabled() {
        return vibrateEnabled;
    }

    @Override
    public long[] getVibratePattern() {
        return vibratePattern;
    }

    @Override
    public boolean isLightsEnabled() {
        return lightsEnabled;
    }

    @Override
    public int[] getLights() {
        return lights;
    }

    @Override
    public int getNumber() {
        return number;
    }

    public void setCarouselIndex(int carouselIndex) {
        this.carouselIndex = carouselIndex;
    }

    @Override
    public String toString() {
        return "CarouselNotificationDetails{" +
                "subject='" + subject + '\'' +
                ", message='" + message + '\'' +
                ", notificationUUID='" + notificationUUID + '\'' +
                ", carouselIndex=" + carouselIndex +
                ", payload='" + payload + '\'' +
                ", group='" + group + '\'' +
                ", attribution='" + attribution + '\'' +
                ", mailingId='" + mailingId + '\'' +
                ", sensitive=" + sensitive +
                ", highPriority=" + highPriority +
                ", soundEnabled=" + soundEnabled +
                ", soundResourceId=" + soundResourceId +
                ", vibrateEnabled=" + vibrateEnabled +
                ", vibratePattern=" + Arrays.toString(vibratePattern) +
                ", lightsEnabled=" + lightsEnabled +
                ", lights=" + Arrays.toString(lights) +
                ", number=" + number +
                '}';
    }
}
