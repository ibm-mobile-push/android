/*
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2019.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.carousel;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.widget.RemoteViews;

import com.ibm.mce.sdk.api.MediaManager;
import com.ibm.mce.sdk.api.notification.Action;
import com.ibm.mce.sdk.api.notification.MceNotificationActionRegistry;
import com.ibm.mce.sdk.api.notification.MceNotificationType;
import com.ibm.mce.sdk.api.notification.NotificationDetails;
import com.ibm.mce.sdk.notification.ActionImpl;
import com.ibm.mce.sdk.notification.NotificationsUtility;
import com.ibm.mce.sdk.util.Logger;
import com.ibm.mce.sdk.util.property.PropertyContainerJsonTemplate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class CarouselNotificationType implements MceNotificationType {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2019, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    private static final String TAG = "CarouselNotificationType";

    private static final String NEXT_LABEL_KEY = "next";
    private static final String PREV_LABEL_KEY = "prev";
    private static final String CAROUSEL_KEY = "carousel";

    private static final String IMAGE_URL_KEY = "image";
    private static final String ACTION_KEY = "action";


    @Override
    public Notification createNotification(Context context, Bundle extras, NotificationDetails notificationDetails, int icon, int actionFlags, UUID notifUUID) {
        return createNotification(context, new CarouselNotificationDetails(notificationDetails, notifUUID.toString(), 1), true);
    }


    public static Notification createNotification(final Context context, final CarouselNotificationDetails carouselNotificationDetails, boolean verifyImages) {
        try {
            Logger.d(TAG, "Creating notification from "+carouselNotificationDetails);
            JSONObject carouselPayload = new JSONObject(carouselNotificationDetails.getPayload());
            final List<CarouselItem> carouselItems = extractCarouselItems(carouselPayload.getJSONArray(CAROUSEL_KEY));
            int currentIndex = carouselNotificationDetails.getCarouselIndex();
            if (currentIndex > carouselItems.size()) {
                carouselNotificationDetails.setCarouselIndex(1);
            } else if (currentIndex < 1) {
                carouselNotificationDetails.setCarouselIndex(carouselItems.size());
            }
            final CarouselItem currentItem = carouselItems.get(carouselNotificationDetails.getCarouselIndex() - 1);
            if(Build.VERSION.SDK_INT>= Build.VERSION_CODES.LOLLIPOP) {
                return createLolipopOrAboveCarouselNotification(context, carouselNotificationDetails, verifyImages, carouselPayload, carouselItems, currentItem);
            } else {
                return createBelowLolipopCarouselNotification(context, carouselNotificationDetails, currentItem);
            }

        } catch (Throwable t) {
            Logger.e(TAG, "Failed to create carousel notification", t);
            return null;
        }

    }

    private static Notification createLolipopOrAboveCarouselNotification(Context context, CarouselNotificationDetails carouselNotificationDetails, boolean verifyImages, JSONObject carouselPayload, List<CarouselItem> carouselItems, CarouselItem currentItem) throws JSONException {
        if (verifyImages) {
            if (!verifyImages(context, carouselNotificationDetails, carouselItems))
                return null;
        }
        Logger.d(TAG, "Creating a new carousel notification");
        int carouselLayoutId = context.getResources().getIdentifier("mce_carousel_notification", "layout", context.getPackageName());
        final RemoteViews remoteViews = new RemoteViews(context.getPackageName(), carouselLayoutId);

        int imgLabelId = context.getResources().getIdentifier("mce_carousel_text", "id", context.getPackageName());
        int imgId = context.getResources().getIdentifier("mce_carousel_img", "id", context.getPackageName());
        int nextButtonId = context.getResources().getIdentifier("mce_carousel_next", "id", context.getPackageName());
        int prevButtonId = context.getResources().getIdentifier("mce_carousel_prev", "id", context.getPackageName());


        populateCarouselView(context, remoteViews, carouselPayload, carouselNotificationDetails, carouselItems, currentItem, nextButtonId, prevButtonId, imgLabelId, imgId);

        setCarouselNotificationActions(context, carouselNotificationDetails, currentItem, remoteViews, imgLabelId, imgId, nextButtonId, prevButtonId);


        NotificationCompat.Builder builder = NotificationsUtility.createCompatBuilder(context, carouselNotificationDetails);
        builder.setStyle(new NotificationCompat.DecoratedCustomViewStyle())
                .setOnlyAlertOnce(true)
                .setCustomBigContentView(remoteViews)
                .setAutoCancel(false)
                .setWhen(System.currentTimeMillis())
                .setCustomBigContentView(remoteViews);

        return builder.build();
    }

    private static Notification createBelowLolipopCarouselNotification(Context context, CarouselNotificationDetails carouselNotificationDetails, CarouselItem currentItem) {
        PendingIntent actionPendingIntent = NotificationsUtility.createActionPendingIntent(context, new Bundle(), currentItem.getAction(), carouselNotificationDetails.getMceNotificationPayload(), 0, null, carouselNotificationDetails.getNotificationUUID(), true);
        NotificationCompat.Builder builder = NotificationsUtility.createCompatBuilder(context, carouselNotificationDetails);
        builder.setAutoCancel(true)
                .setContentIntent(actionPendingIntent);
        return builder.build();
    }

    private static void setCarouselNotificationActions(Context context, CarouselNotificationDetails carouselNotificationDetails, CarouselItem currentItem, RemoteViews remoteViews, int imgLabelId, int imgId, int nextButtonId, int prevButtonId) throws JSONException {
        PendingIntent actionPendingIntent = NotificationsUtility.createActionPendingIntent(context, new Bundle(), currentItem.getAction(), carouselNotificationDetails.getMceNotificationPayload(), 0, null, carouselNotificationDetails.getNotificationUUID(), true);
        remoteViews.setOnClickPendingIntent(imgId, actionPendingIntent);
        remoteViews.setOnClickPendingIntent(imgLabelId, actionPendingIntent);

        PropertyContainerJsonTemplate propertyContainerJsonTemplate = new PropertyContainerJsonTemplate();
        Map<String, String> payload = new HashMap<String, String>();
        payload.put(CarouselIterationOperation.FORWARD_KEY, "true");
        payload.put(CarouselIterationOperation.DETAILS_KEY, propertyContainerJsonTemplate.toJSON(carouselNotificationDetails).toString());
        ActionImpl nextAction = new ActionImpl(CarouselIterationOperation.ACTION_TYPE, "", payload);
        PendingIntent nextPendingIntent = NotificationsUtility.createActionPendingIntent(context, new Bundle(), nextAction, carouselNotificationDetails.getMceNotificationPayload(), 0, null, carouselNotificationDetails.getNotificationUUID(), false);
        remoteViews.setOnClickPendingIntent(nextButtonId, nextPendingIntent);

        payload.remove(CarouselIterationOperation.FORWARD_KEY);
        ActionImpl prevAction = new ActionImpl(CarouselIterationOperation.ACTION_TYPE, "", payload);
        PendingIntent prevPendingIntent = NotificationsUtility.createActionPendingIntent(context, new Bundle(), prevAction, carouselNotificationDetails.getMceNotificationPayload(), 0, null, carouselNotificationDetails.getNotificationUUID(), false);
        remoteViews.setOnClickPendingIntent(prevButtonId, prevPendingIntent);
    }

    private static void populateCarouselView(final Context context, final RemoteViews remoteViews, JSONObject carouselPayload, CarouselNotificationDetails carouselNotificationDetails, List<CarouselItem> carouselItems, CarouselItem currentItem, int nextButtonId, int prevButtonId, int imgLabelId, final int imgId)
    {
        String nextLabel = carouselPayload.optString(NEXT_LABEL_KEY, NEXT_LABEL_KEY);
        remoteViews.setTextViewText(nextButtonId, nextLabel);
        String prevLabel = carouselPayload.optString(PREV_LABEL_KEY, PREV_LABEL_KEY);
        remoteViews.setTextViewText(prevButtonId, prevLabel);
        String imgLabel = currentItem.getAction().getName();
        remoteViews.setTextViewText(imgLabelId, imgLabel);
        Bitmap image = MediaManager.getImageCache().getImage(currentItem.getImageUrl(), false);
        if (image == null) {
            remoteViews.setImageViewResource(imgId, context.getResources().getIdentifier("mce_carousel_img_wait", "id", context.getPackageName()));
            MediaManager.loadImage(currentItem.getImageUrl(), null, new MediaManager.OnImageLoadTask() {
                @Override
                public void imageLoaded(String url, Bitmap image) {
                    remoteViews.setImageViewBitmap(imgId, image);
                }

                @Override
                public void imageLoadFailed(String url) {
                    remoteViews.setImageViewResource(imgId, context.getResources().getIdentifier("mce_carousel_img_fail", "id", context.getPackageName()));
                }
            });
        } else {
            remoteViews.setImageViewBitmap(imgId, image);
        }
    }

    private static boolean verifyImages(final Context context, final CarouselNotificationDetails carouselNotificationDetails, final List<CarouselItem> carouselItems) {
        for (CarouselItem carouselItem : carouselItems) {
            if (!MediaManager.getImageCache().hasImage(carouselItem.getImageUrl())) {
                (new Thread() {
                    @Override
                    public void run() {
                        for (CarouselItem carouselItem : carouselItems) {
                            if (!MediaManager.getImageCache().hasImage(carouselItem.getImageUrl())) {
                                MediaManager.loadImageInCurrentThread(carouselItem.getImageUrl());
                            }
                        }
                        Notification notification = createNotification(context, carouselNotificationDetails, false);
                        NotificationsUtility.postCreate(context, (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE), notification, carouselNotificationDetails, carouselNotificationDetails.getNotificationUUID());
                    }
                }).start();
                return false;
            }
        }
        return true;
    }

    private static List<CarouselItem> extractCarouselItems(JSONArray itemsArray) throws JSONException {
        List<CarouselItem> carouselItems = new LinkedList<CarouselItem>();
        for(int i = 0; i < itemsArray.length(); ++i) {
            JSONObject carouselItemJSON = itemsArray.getJSONObject(i);
            String imageUrl = carouselItemJSON.getString(IMAGE_URL_KEY);
            Action action = NotificationsUtility.extractAction(carouselItemJSON.getJSONObject(ACTION_KEY), false);
            carouselItems.add(new CarouselItem(imageUrl, action));
        }
        return carouselItems;
    }

    @Override
    public void init(Context context, JSONObject initOptions) {
        MceNotificationActionRegistry.registerNotificationAction(CarouselIterationOperation.ACTION_TYPE, new CarouselIterationOperation());
    }
}
