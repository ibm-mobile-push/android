/*
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2019.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.carousel;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.ibm.mce.sdk.api.notification.Action;
import com.ibm.mce.sdk.api.notification.MceNotificationAction;
import com.ibm.mce.sdk.api.notification.MceNotificationActionRegistry;
import com.ibm.mce.sdk.api.notification.NotificationDetails;
import com.ibm.mce.sdk.notification.NotificationsUtility;
import com.ibm.mce.sdk.util.Logger;
import com.ibm.mce.sdk.util.property.PropertyContainerJsonTemplate;


import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class CarouselItemNotificationAction implements MceNotificationAction {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2019, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    private static final String TAG = "CarouselItemNotificationAction";

    public static final String ACTION_TYPE = "carouselItem";

    public static final String ACTION_KEY = "action";
    public static final String DETAILS_KEY = "details";

    @Override
    public void handleAction(Context context, String type, String name, String attribution, String mailingId, Map<String, String> payload, boolean fromNotification) {
        try {
            PropertyContainerJsonTemplate propertyContainerJsonTemplate = new PropertyContainerJsonTemplate();
            CarouselNotificationDetails carouselNotificationDetails = (CarouselNotificationDetails)propertyContainerJsonTemplate.fromJSON(new JSONObject(payload.get(DETAILS_KEY)));
            Action action = NotificationsUtility.extractAction(new JSONObject(payload.get(ACTION_KEY)), false);
            Map<String, String> innerActionPayload = new HashMap<String, String>();
            for(String key : action.getPayloadKeys()) {
                innerActionPayload.put(key, action.getPayloadValue(key));
            }
            MceNotificationAction mceNotificationAction = MceNotificationActionRegistry.getNotificationAction(action.getType());
            mceNotificationAction.handleAction(context, action.getType(), action.getName(), attribution, mailingId, innerActionPayload, fromNotification);
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.cancel(carouselNotificationDetails.getNotificationUUID().hashCode());
            Intent it = new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
            context.sendBroadcast(it);
        } catch (Throwable t) {
            Logger.e(TAG, "Failed to execute carousel item action", t);
        }

    }

    @Override
    public void init(Context context, JSONObject initOptions) {

    }

    @Override
    public void update(Context context, JSONObject updateOptions) {

    }

    @Override
    public boolean shouldDisplayNotification(Context context, NotificationDetails notificationDetails, Bundle sourceBundle) {
        return false;
    }
}
