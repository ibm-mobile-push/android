/*
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2019.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.carousel;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.widget.RemoteViews;

import com.ibm.mce.sdk.api.Constants;
import com.ibm.mce.sdk.api.MceSdk;
import com.ibm.mce.sdk.api.MediaManager;
import com.ibm.mce.sdk.api.notification.Action;
import com.ibm.mce.sdk.api.notification.MceNotificationActionRegistry;
import com.ibm.mce.sdk.api.notification.MceNotificationType;
import com.ibm.mce.sdk.api.notification.NotificationDetails;
import com.ibm.mce.sdk.notification.ActionImpl;
import com.ibm.mce.sdk.notification.NotificationsUtility;
import com.ibm.mce.sdk.util.Logger;
import com.ibm.mce.sdk.util.property.PropertyContainerJsonTemplate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class CarouselNotificationType implements MceNotificationType {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2019, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    private static final String TAG = "CarouselNotificationType";

    private static final String NEXT_LABEL_KEY = "next";
    private static final String PREV_LABEL_KEY = "prev";
    private static final String CAROUSEL_KEY = "carousel";

    private static final String IMAGE_URL_KEY = "image";
    private static final String ACTION_KEY = "action";


    @Override
    public Notification createNotification(Context context, Bundle extras, NotificationDetails notificationDetails, int icon, int actionFlags, UUID notifUUID) {
        return createNotification(context, new CarouselNotificationDetails(notificationDetails, notifUUID.toString(), 1), true);
    }


    public static Notification createNotification(final Context context, final CarouselNotificationDetails carouselNotificationDetails, boolean verifyImages) {
        try {
            Logger.d(TAG, "Creating notification from "+carouselNotificationDetails);
            JSONObject carouselPayload = new JSONObject(carouselNotificationDetails.getPayload());
            final List<CarouselItem> carouselItems = extractCarouselItems(carouselPayload.getJSONArray(CAROUSEL_KEY));
            if(verifyImages) {
                for(CarouselItem carouselItem : carouselItems) {
                    if(!MediaManager.getImageCache().hasImage(carouselItem.getImageUrl())) {
                        (new Thread() {
                            @Override
                            public void run() {
                                for(CarouselItem carouselItem : carouselItems) {
                                    if(!MediaManager.getImageCache().hasImage(carouselItem.getImageUrl())) {
                                        MediaManager.loadImageInCurrentThread(carouselItem.getImageUrl());
                                    }
                                }
                                Notification notification = createNotification(context, carouselNotificationDetails,false);
                                NotificationsUtility.postCreate(context, (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE),notification, carouselNotificationDetails, carouselNotificationDetails.getNotificationUUID());
                            }
                        }).start();
                        return null;
                    }
                }
            }
            Logger.d(TAG, "Creating a new carousel notification");
            int icon =  MceSdk.getNotificationsClient().getNotificationsPreference().getIcon(context);
            int carouselLayoutId = context.getResources().getIdentifier("mce_carousel_notification", "layout", context.getPackageName());
            final RemoteViews remoteViews = new RemoteViews(context.getPackageName(), carouselLayoutId);

            String nextLabel = carouselPayload.optString(NEXT_LABEL_KEY, NEXT_LABEL_KEY);
            int nextButtonId = context.getResources().getIdentifier("mce_carousel_next", "id", context.getPackageName());
            remoteViews.setTextViewText(nextButtonId, nextLabel);
            String prevLabel = carouselPayload.optString(PREV_LABEL_KEY, PREV_LABEL_KEY);
            int prevButtonId = context.getResources().getIdentifier("mce_carousel_prev", "id", context.getPackageName());
            remoteViews.setTextViewText(prevButtonId, prevLabel);
            int currentIndex = carouselNotificationDetails.getCarouselIndex();
            if(currentIndex > carouselItems.size()) {
                carouselNotificationDetails.setCarouselIndex(1);
            } else if(currentIndex < 1) {
                carouselNotificationDetails.setCarouselIndex(carouselItems.size());
            }
            final CarouselItem currentItem = carouselItems.get(carouselNotificationDetails.getCarouselIndex() - 1);
            String imgLabel = currentItem.getAction().getName();
            int imgLabelId = context.getResources().getIdentifier("mce_carousel_text", "id", context.getPackageName());
            remoteViews.setTextViewText(imgLabelId, imgLabel);
            final int imgId = context.getResources().getIdentifier("mce_carousel_img", "id", context.getPackageName());
            Bitmap image = MediaManager.getImageCache().getImage(currentItem.getImageUrl(), false);
            if(image == null) {
                remoteViews.setImageViewResource(imgId, context.getResources().getIdentifier("mce_carousel_img_wait", "id", context.getPackageName()));
                MediaManager.loadImage(currentItem.getImageUrl(), null, new MediaManager.OnImageLoadTask() {
                    @Override
                    public void imageLoaded(String url, Bitmap image) {
                        remoteViews.setImageViewBitmap(imgId, image);
                    }

                    @Override
                    public void imageLoadFailed(String url) {
                        remoteViews.setImageViewResource(imgId, context.getResources().getIdentifier("mce_carousel_img_fail", "id", context.getPackageName()));
                    }
                });
            } else {
                remoteViews.setImageViewBitmap(imgId, image);
            }

            PendingIntent actionPendingIntent = NotificationsUtility.createActionPendingIntent(context, new Bundle(), createCarouselItemAction(currentItem.getAction(), carouselNotificationDetails), carouselNotificationDetails.getMceNotificationPayload(), 0,null, carouselNotificationDetails.getNotificationUUID());
            remoteViews.setOnClickPendingIntent(imgId, actionPendingIntent);
            remoteViews.setOnClickPendingIntent(imgLabelId, actionPendingIntent);

            PropertyContainerJsonTemplate propertyContainerJsonTemplate = new PropertyContainerJsonTemplate();
            Map<String, String> payload = new HashMap<String, String>();
            payload.put(CarouselIterationAction.FORWARD_KEY,"true");
            payload.put(CarouselIterationAction.DETAILS_KEY, propertyContainerJsonTemplate.toJSON(carouselNotificationDetails).toString());
            ActionImpl nextAction = new ActionImpl(CarouselIterationAction.ACTION_TYPE,"", payload);
            PendingIntent nextPendingIntent = NotificationsUtility.createActionPendingIntent(context, new Bundle(), nextAction, carouselNotificationDetails.getMceNotificationPayload(), 0,null, carouselNotificationDetails.getNotificationUUID());
            remoteViews.setOnClickPendingIntent(nextButtonId, nextPendingIntent);

            payload.remove(CarouselIterationAction.FORWARD_KEY);
            ActionImpl prevAction = new ActionImpl(CarouselIterationAction.ACTION_TYPE,"", payload);
            PendingIntent prevPendingIntent = NotificationsUtility.createActionPendingIntent(context, new Bundle(), prevAction, carouselNotificationDetails.getMceNotificationPayload(), 0,null, carouselNotificationDetails.getNotificationUUID());
            remoteViews.setOnClickPendingIntent(prevButtonId, prevPendingIntent);



            NotificationCompat.Builder builder = NotificationsUtility.createCompatBuilder(context, carouselNotificationDetails);
            builder.setSmallIcon(icon)
                    .setStyle(new NotificationCompat.DecoratedCustomViewStyle())
                    .setOnlyAlertOnce(true)
                    .setCustomBigContentView(remoteViews)
                    .setAutoCancel(false)
                    .setWhen(System.currentTimeMillis())
                    .setCustomBigContentView(remoteViews);

            return builder.build();

        } catch (Throwable t) {
            Logger.e(TAG, "Failed to create carousel notification", t);
            return null;
        }

    }

    private static List<CarouselItem> extractCarouselItems(JSONArray itemsArray) throws JSONException {
        List<CarouselItem> carouselItems = new LinkedList<CarouselItem>();
        for(int i = 0; i < itemsArray.length(); ++i) {
            JSONObject carouselItemJSON = itemsArray.getJSONObject(i);
            String imageUrl = carouselItemJSON.getString(IMAGE_URL_KEY);
            Action action = NotificationsUtility.extractAction(carouselItemJSON.getJSONObject(ACTION_KEY), false);
            carouselItems.add(new CarouselItem(imageUrl, action));
        }
        return carouselItems;
    }

    private static Action createCarouselItemAction(Action action, CarouselNotificationDetails carouselNotificationDetails) throws JSONException {
        Map<String, String> payload = new HashMap<String,String>();
        payload.put(CarouselItemNotificationAction.ACTION_KEY, actionToJsonString(action));
        PropertyContainerJsonTemplate propertyContainerJsonTemplate = new PropertyContainerJsonTemplate();
        payload.put(CarouselItemNotificationAction.DETAILS_KEY, propertyContainerJsonTemplate.toJSON(carouselNotificationDetails).toString());
        ActionImpl carouselItemAction = new ActionImpl(CarouselItemNotificationAction.ACTION_TYPE, "",payload);
        return carouselItemAction;
    }

    private static String actionToJsonString(Action action) throws JSONException {
        JSONObject actionJSON = new JSONObject();
        actionJSON.put(Constants.Notifications.TYPE_KEY, action.getType());
        if(action.getName() != null) {
            actionJSON.put(Constants.Notifications.NAME_KEY, action.getName());
        }
        for(String key : action.getPayloadKeys()) {
            actionJSON.put(key, action.getPayloadValue(key));
        }
        return actionJSON.toString();
    }

    @Override
    public void init(Context context, JSONObject initOptions) {
        MceNotificationActionRegistry.registerNotificationAction(CarouselIterationAction.ACTION_TYPE, new CarouselIterationAction());
        MceNotificationActionRegistry.registerNotificationAction(CarouselItemNotificationAction.ACTION_TYPE, new CarouselItemNotificationAction());
    }
}
