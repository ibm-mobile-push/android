/*
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2019.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.carousel;

import com.ibm.mce.sdk.api.notification.Action;

public class CarouselItem {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2019, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    private String imageUrl;
    private Action action;

    public CarouselItem(String imageUrl, Action action) {
        this.imageUrl = imageUrl;
        this.action = action;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public Action getAction() {
        return action;
    }
}
