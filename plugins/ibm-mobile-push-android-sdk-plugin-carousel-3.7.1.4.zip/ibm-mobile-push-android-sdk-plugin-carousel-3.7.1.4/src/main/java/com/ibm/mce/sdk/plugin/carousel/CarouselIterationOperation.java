/*
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2019.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.carousel;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Bundle;

import com.ibm.mce.sdk.api.notification.MceNotificationOperation;
import com.ibm.mce.sdk.api.notification.NotificationDetails;
import com.ibm.mce.sdk.notification.NotificationsUtility;
import com.ibm.mce.sdk.util.Logger;
import com.ibm.mce.sdk.util.property.PropertyContainerJsonTemplate;

import org.json.JSONObject;

import java.util.Map;

public class CarouselIterationOperation implements MceNotificationOperation {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2019, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    private static final String TAG = "CarouselIterationOperation";

    public static final String ACTION_TYPE = "carouselIteration";

    public static final String FORWARD_KEY = "forward";
    public static final String DETAILS_KEY = "details";

    @Override
    public void handleAction(Context context, String type, String name, String attribution, String mailingId, Map<String, String> payload, boolean fromNotification) {
        try {
            boolean forward = payload.containsKey(FORWARD_KEY);
            PropertyContainerJsonTemplate propertyContainerJsonTemplate = new PropertyContainerJsonTemplate();
            CarouselNotificationDetails carouselNotificationDetails = (CarouselNotificationDetails)propertyContainerJsonTemplate.fromJSON(new JSONObject(payload.get(DETAILS_KEY)));
            if(forward) {
                carouselNotificationDetails.setCarouselIndex(carouselNotificationDetails.getCarouselIndex() + 1);
            } else {
                carouselNotificationDetails.setCarouselIndex(carouselNotificationDetails.getCarouselIndex() - 1);
            }
            Notification notification = CarouselNotificationType.createNotification(context, carouselNotificationDetails, true);
            NotificationsUtility.postCreate(context, (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE),notification, carouselNotificationDetails, carouselNotificationDetails.getNotificationUUID());

        } catch (Throwable t) {
            Logger.e(TAG, "Failed to activate carousel iteration action", t);
        }
    }

    @Override
    public void init(Context context, JSONObject initOptions) {

    }

    @Override
    public void update(Context context, JSONObject updateOptions) {

    }

    @Override
    public boolean shouldDisplayNotification(Context context, NotificationDetails notificationDetails, Bundle sourceBundle) {
        return true;
    }
}
