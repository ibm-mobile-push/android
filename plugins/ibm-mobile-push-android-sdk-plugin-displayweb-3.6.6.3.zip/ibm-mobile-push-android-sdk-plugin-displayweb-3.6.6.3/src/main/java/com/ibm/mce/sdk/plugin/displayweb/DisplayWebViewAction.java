/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.displayweb;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.ibm.mce.sdk.api.notification.MceNotificationAction;
import com.ibm.mce.sdk.api.notification.NotificationDetails;

import org.json.JSONObject;

import java.util.Map;

/**
 * This class is an MCE notification action implementation that displays a url within a native view. The event has one property - value, which is the
 * url for display.
 * When the action is clicked, the url is displayed in a url display activity
 */
public class DisplayWebViewAction implements MceNotificationAction {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    /**
     * This method handles the display url action
     * @param context The application context
     * @param type The notification action type
     * @param name The notification action name (can be null)
     * @param attribution The notification attribution (can be null)
     * @param mailingId The notification mailing id
     * @param payload The notification payload. The map containing the url under "value".
     */
    public void handleAction(Context context, String type, String name, String attribution, String mailingId, Map<String, String> payload, boolean fromNotification)  {
        Intent it = new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
        context.sendBroadcast(it);
        Intent intent = new Intent(context, DisplayWebViewActivity.class);
        intent.putExtra("url", payload.get("value"));
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    @Override
    public void init(Context context, JSONObject initOptions) {

    }

    @Override
    public void update(Context context, JSONObject updateOptions) {

    }

    @Override
    public boolean shouldDisplayNotification(Context context, NotificationDetails notificationDetails, Bundle sourceBundle) {
        return true;
    }
}