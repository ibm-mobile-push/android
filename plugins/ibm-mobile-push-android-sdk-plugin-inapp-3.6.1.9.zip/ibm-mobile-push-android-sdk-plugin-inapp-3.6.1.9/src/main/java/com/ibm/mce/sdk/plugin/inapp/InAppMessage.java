/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class InAppMessage implements Serializable {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    private final int id;
    private final String attribution;
    private final Date triggerDate;
    private final Date expirationDate;
    private final List<String> rules;
    private final int maxViews;
    private final String templateName;
    private final JSONObject templateContent;
    private final List<Action> actions;
    private final InAppMessageRealm source;

    // ArrayList -> RealmList
    // Convert ArrayList

    public InAppMessage(InAppMessageRealm messageRealm){
        this.source = messageRealm;
        this.id = messageRealm.getId();
        this.attribution = messageRealm.getAttribution();
        this.triggerDate = messageRealm.getTriggerDate();
        this.expirationDate = messageRealm.getExpirationDate();
        this.maxViews = messageRealm.getMaxViews();
        this.templateName = messageRealm.getTemplateName();

        JSONObject templateContent = new JSONObject();
        try {
            templateContent = new JSONObject(messageRealm.getTemplateContent());
        } catch (JSONException e) {
            Log.d(InAppMessage.class.getName(), "Error parsing template content. Content should be Json Object. " + e.getMessage());
        }
        this.templateContent = templateContent;

        List<Rule> ruleRealmList = messageRealm.getRules();
        List<String> convertedRules = new ArrayList<String>();
        for(Rule rule : ruleRealmList) convertedRules.add(rule.getVal());
        this.rules = convertedRules;
        List<ActionRealm> actionRealmList = messageRealm.getActions();
        ArrayList<Action> convertedActions = new ArrayList<Action>();
        for(ActionRealm actionRealm: actionRealmList) convertedActions.add(new Action(actionRealm));
        this.actions = convertedActions;


    }

    public String getAttribution() {
        return attribution;
    }

    public Date getTriggerDate() {
        return triggerDate;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public List<String> getRules() {
        return rules;
    }

    public int getMaxViews() {
        return maxViews;
    }

    public String getTemplateName() {
        return templateName;
    }

    public JSONObject getTemplateContent() {
        return templateContent;
    }

    public List<Action> getActions() {
        return actions;
    }

    public int getId() {
        return id;
    }

    public InAppMessageRealm getSource() {
        return source;
    }
}
