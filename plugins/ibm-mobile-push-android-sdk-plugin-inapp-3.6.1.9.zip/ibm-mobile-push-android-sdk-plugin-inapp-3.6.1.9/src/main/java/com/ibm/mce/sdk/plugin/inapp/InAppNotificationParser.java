/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.content.Context;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.google.gson.TypeAdapter;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.ibm.mce.sdk.util.Iso8601;
import com.ibm.mce.sdk.util.Logger;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.util.Date;

import io.realm.RealmList;
import io.realm.RealmObject;

public class InAppNotificationParser {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    private static class InAppDateDeserializer implements JsonDeserializer<Date> {
        @Override
        public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
            try {
                return Iso8601.toDate(json.getAsString());
            } catch (ParseException e) {
                throw new JsonParseException(e);
            }
        }
    }

    public static InAppMessageRealm parse(Context context, String notification, String attribution) {

        Type token = new TypeToken<RealmList<Rule>>() {
        }.getType();
        Gson gson = new GsonBuilder()
                .setExclusionStrategies(new ExclusionStrategy() {
                    @Override
                    public boolean shouldSkipField(FieldAttributes f) {
                        return f.getDeclaringClass().equals(RealmObject.class);
                    }

                    @Override
                    public boolean shouldSkipClass(Class<?> clazz) {
                        return false;
                    }
                }).registerTypeAdapter(token, new TypeAdapter<RealmList<Rule>>() {

                    @Override
                    public void write(com.google.gson.stream.JsonWriter out, RealmList<Rule> value) throws IOException {
                        // no-op
                    }

                    @Override
                    public RealmList<Rule> read(JsonReader in) throws IOException {
                        RealmList<Rule> list = new RealmList<Rule>();
                        in.beginArray();
                        while (in.hasNext()) {
                            list.add(new Rule(in.nextString()));
                        }
                        in.endArray();
                        return list;
                    }
                })
                .registerTypeAdapter(Date.class, new InAppDateDeserializer()).create();


        /*
         * Realm can't handle JSON Object so I need to convert it to string but Gson
         * does not know how to convert Json Object to String.
         */
        JsonParser parser = new JsonParser();
        JsonObject element = (JsonObject) parser.parse(notification);
        String contentString = element.getAsJsonObject("content").toString();
        element.remove("content");
        InAppMessageRealm inAppMessageRealm = gson.fromJson(element, InAppMessageRealm.class);
        inAppMessageRealm.setTemplateContent(contentString);
        inAppMessageRealm.setId(InAppStorage.getNextPrimaryKey(context));
        if(inAppMessageRealm.getExpirationDate() == null) {
            inAppMessageRealm.setExpirationDate(new Date(System.currentTimeMillis()+365*24*60*60*1000));
        }
        if(inAppMessageRealm.getTriggerDate() == null) {
            inAppMessageRealm.setTriggerDate(new Date());
        }
        if(inAppMessageRealm.getMaxViews() <= 0) {
            inAppMessageRealm.setMaxViews(1);
        }
        inAppMessageRealm.setAttribution(attribution);
        return inAppMessageRealm;
    }

}
