/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.os.Bundle;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Action {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    private String name;
    private JSONObject value;

    Action(String name, JSONObject value){
        this.name = name;
        this.value = value;
    }

    public Action(ActionRealm actionRealm){
        this.name = actionRealm.getName();
        try {
            this.value = new JSONObject(actionRealm.getValue());
        } catch (JSONException e) {
            Log.d("MCE", "Error converting raw value to jsonObject value");
        }
    }

    public String getName() {
        return this.name;
    }

    public JSONObject getValue() {
        return this.value;
    }
}



