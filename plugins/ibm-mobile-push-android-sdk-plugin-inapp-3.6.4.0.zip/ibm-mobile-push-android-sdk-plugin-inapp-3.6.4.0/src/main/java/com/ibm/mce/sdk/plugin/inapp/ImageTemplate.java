/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2016.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;

import com.ibm.mce.sdk.util.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class ImageTemplate extends BaseInAppTemplate {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2016, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";
    public static final String IMAGE_KEY = "image";
    public static final String TITLE_KEY = "title";
    public static final String TEXT_KEY = "text";
    public static final String DURATION_KEY = "duration";


    @Override
    public Map<String, Object> createOfflineResources(Context context, InAppMessage message) {
        Map<String, Object> resources = new HashMap<String, Object>();
        try {
            String src = message.getTemplateContent().getString(IMAGE_KEY);
            resources.put(IMAGE_KEY, getBitmapFromURL(src));
         } catch (Exception e) {

        }
        return resources;
    }

    @Override
    public boolean requiresOfflineResources() {
        return true;
    }

    @Override
    protected void setupArguments(Context context, InAppMessage message, Bundle arguments, Map<String, Object> offlineResources) throws JSONException {
        if(offlineResources.containsKey(IMAGE_KEY)) {
            arguments.putParcelable(IMAGE_KEY, (Bitmap)offlineResources.get(IMAGE_KEY));
        }
        arguments.putString(TITLE_KEY, message.getTemplateContent().optString(TITLE_KEY));
        arguments.putString(TEXT_KEY, message.getTemplateContent().optString(TEXT_KEY));
        arguments.putInt(DURATION_KEY, message.getTemplateContent().optInt(DURATION_KEY, 5));
    }

    @Override
    protected String getFragmentLayoutId() {
        return "mce-image";
    }

    @Override
    protected InAppFragment createFragment() {
        return new ImageFragment();
    }

    private static Bitmap getBitmapFromURL(String bitmapURL) {
        try {
            URL url = new URL(bitmapURL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            return BitmapFactory.decodeStream(input);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }




}

