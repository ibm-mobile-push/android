/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.ibm.mce.sdk.util.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.Map;


public class MiniTemplate extends BaseInAppTemplate {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    public static final String ORIENTATION_TOP="top";
    public static final String ORIENTATION_BOTTOM="bottom";
    public static final String ICON_KEY = "icon";
    public static final String COLOR_KEY = "color";
    public static final String TEXT_KEY = "text";
    public static final String ORIENTATION_KEY = "orientation";
    public static final String FOREGROUND_KEY = "foreground";
    public static final String DURATION_KEY = "duration";

    @Override
    public boolean requiresOfflineResources() {
        return false;
    }

    @Override
    public Map<String, Object> createOfflineResources(Context context, InAppMessage message) {
        return null;
    }

    @Override
    protected void setupArguments(Context context, InAppMessage message, Bundle arguments, Map<String, Object> offlineResources) throws JSONException {
        arguments.putString(ICON_KEY, message.getTemplateContent().getString(ICON_KEY));
        arguments.putString(COLOR_KEY, message.getTemplateContent().getString(COLOR_KEY));
        arguments.putString(TEXT_KEY, message.getTemplateContent().getString(TEXT_KEY));
        arguments.putString(ORIENTATION_KEY, message.getTemplateContent().optString(ORIENTATION_KEY, ORIENTATION_BOTTOM));
        arguments.putString(FOREGROUND_KEY, message.getTemplateContent().optString(FOREGROUND_KEY, null));
        arguments.putInt(DURATION_KEY, message.getTemplateContent().optInt(DURATION_KEY, 5));

    }

    @Override
    protected String getFragmentLayoutId() {
        return "mce-mini";
    }

    @Override
    protected InAppFragment createFragment() {
        return new MiniFragment();
    }

}

