/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2017.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;

import com.ibm.mce.sdk.util.Logger;
import com.ibm.mce.sdk.util.json.JsonUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

class InAppMessagesDatabaseHelper extends SQLiteOpenHelper {
    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2017, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    private static final String TAG="InAppMessagesDatabaseHelper";

    private static final String DB_NAME = "mceInappMessages.sqlite";
    private static final int VERSION = 1;

    private static final String MESSAGES_TABLE_NAME = "messages";

    private static final String COLUMN_MESSAGE_ID = "_id";
    private static final String COLUMN_MAILING_ID = "mailingId";
    private static final String COLUMN_ATTRIBUTION = "attribution";
    private static final String COLUMN_TRIGGER_DATE = "triggerDate";
    private static final String COLUMN_EXPIRATION_DATE = "expirationDate";
    private static final String COLUMN_MAX_VIEWS = "maxViews";
    private static final String COLUMN_VIEWS = "views";
    private static final String COLUMN_TEMPLATE_NAME = "templateName";
    private static final String COLUMN_TEMPLATE = "template";
    private static final String COLUMN_ACTIONS = "actions";
    private static final String COLUMN_RULES = "rules";

    private static final String[] MESSAGES_TABLE_COLUMNS = {MESSAGES_TABLE_NAME+"."+COLUMN_MESSAGE_ID, MESSAGES_TABLE_NAME+"."+COLUMN_MAILING_ID, MESSAGES_TABLE_NAME+"."+COLUMN_ATTRIBUTION, MESSAGES_TABLE_NAME+"."+COLUMN_TRIGGER_DATE, MESSAGES_TABLE_NAME+"."+COLUMN_EXPIRATION_DATE,
            MESSAGES_TABLE_NAME+"."+COLUMN_MAX_VIEWS, MESSAGES_TABLE_NAME+"."+COLUMN_VIEWS, MESSAGES_TABLE_NAME+"."+COLUMN_TEMPLATE_NAME, MESSAGES_TABLE_NAME+"."+COLUMN_TEMPLATE, MESSAGES_TABLE_NAME+"."+COLUMN_ACTIONS, MESSAGES_TABLE_NAME+"."+COLUMN_RULES};

    private static final String RULES_TABLE_NAME = "rules";

    private static final String COLUMN_RULE_NAME = "name";





    private static InAppMessagesDatabaseHelper inAppMessagesDatabaseHelper;
    public static InAppMessagesDatabaseHelper getInAppMessagesDatabaseHelper(Context context) {
        if (inAppMessagesDatabaseHelper == null)
            inAppMessagesDatabaseHelper = new InAppMessagesDatabaseHelper(context);
        return inAppMessagesDatabaseHelper;
    }

    public InAppMessagesDatabaseHelper(Context context)
    {
        super(context, DB_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        // create inApp messages table
        String createTableSql = "CREATE TABLE IF NOT EXISTS \""+MESSAGES_TABLE_NAME+"\"("+"" +
                "\""+ COLUMN_MESSAGE_ID +"\" TEXT, " +
                "\""+COLUMN_MAILING_ID+"\" Text, "+
                "\""+COLUMN_ATTRIBUTION+"\" Text, "+
                "\""+COLUMN_TRIGGER_DATE+"\" INTEGER, "+
                "\""+COLUMN_EXPIRATION_DATE+"\" INTEGER, "+
                "\""+COLUMN_MAX_VIEWS+"\" INTEGER, "+
                "\""+COLUMN_VIEWS+"\" INTEGER, "+
                "\""+COLUMN_TEMPLATE+"\" Text, "+
                "\""+COLUMN_TEMPLATE_NAME+"\" Text, "+
                "\""+COLUMN_RULES+"\" Text, "+
                "\""+COLUMN_ACTIONS+"\" Text);";
        Logger.d(TAG, createTableSql);
        db.execSQL(createTableSql);

        // create inApp messages rules table
        createTableSql = "CREATE TABLE IF NOT EXISTS \""+RULES_TABLE_NAME+"\"("+"" +
                "\""+ COLUMN_MESSAGE_ID +"\" TEXT, "+
                "\""+COLUMN_RULE_NAME+"\" Text);";
        Logger.d(TAG, createTableSql);
        db.execSQL(createTableSql);

        String messageIdInRulesIndexTableSql = "CREATE INDEX IF NOT EXISTS \"messageIdRulesIndex\" ON \""+RULES_TABLE_NAME+"\"( \""+COLUMN_MESSAGE_ID+"\" );";
        Logger.d(TAG, messageIdInRulesIndexTableSql);
        db.execSQL(messageIdInRulesIndexTableSql);

        String ruleNameInRulesIndexTableSql = "CREATE INDEX IF NOT EXISTS \"ruleNameRulesIdIndex\" ON \""+RULES_TABLE_NAME+"\"( \""+COLUMN_RULE_NAME+"\" );";
        Logger.d(TAG, ruleNameInRulesIndexTableSql);
        db.execSQL(ruleNameInRulesIndexTableSql);

        String messageIdInMessagesIndexTableSql = "CREATE INDEX IF NOT EXISTS \"messageIdMessagesIndex\" ON \""+MESSAGES_TABLE_NAME+"\"( \""+COLUMN_MESSAGE_ID+"\" );";
        Logger.d(TAG, messageIdInMessagesIndexTableSql);
        db.execSQL(messageIdInMessagesIndexTableSql);

        String templateNameInMessagesIndexTableSql = "CREATE INDEX IF NOT EXISTS \"messageIdTemplateIndex\" ON \""+MESSAGES_TABLE_NAME+"\"( \""+COLUMN_TEMPLATE_NAME+"\" );";
        Logger.d(TAG, templateNameInMessagesIndexTableSql);
        db.execSQL(templateNameInMessagesIndexTableSql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        // Implement schema upgrades and data massaging when needed
    }

    public void addMessage(InAppPayload inAppPayload) throws IOException{
        Logger.d(TAG, "Adding new inApp payload: "+inAppPayload);
        SQLiteDatabase db =  getWritableDatabase();
        try {
            db.beginTransaction();
            ContentValues cv = new ContentValues();
            cv.put(COLUMN_MESSAGE_ID, String.valueOf(inAppPayload.getId()));
            cv.put(COLUMN_MAILING_ID, inAppPayload.getMailingId());
            cv.put(COLUMN_ATTRIBUTION, inAppPayload.getAttribution());
            Logger.d(TAG, "Adding trigger date: "+inAppPayload.getTriggerDate().getTime());
            cv.put(COLUMN_TRIGGER_DATE, inAppPayload.getTriggerDate().getTime());
            Logger.d(TAG, "Adding expiration date: "+inAppPayload.getTriggerDate().getTime());
            cv.put(COLUMN_EXPIRATION_DATE, inAppPayload.getExpirationDate().getTime());
            cv.put(COLUMN_MAX_VIEWS, inAppPayload.getMaxViews());
            cv.put(COLUMN_VIEWS, inAppPayload.getViews());
            cv.put(COLUMN_TEMPLATE_NAME, inAppPayload.getTemplateName());
            cv.put(COLUMN_TEMPLATE, inAppPayload.getTemplateContent().toString());
            JSONArray rules = JsonUtil.toJsonStringArray(inAppPayload.getRules());
            if(rules != null) {
                cv.put(COLUMN_RULES, rules.toString());
            }
            JSONArray actions = InAppPayloadJsonTemplate.InAppActionJsonTemplate.LIST_TEMPLATE.toJsonArray(inAppPayload.getActions(), InAppPayloadJsonTemplate.InAppActionJsonTemplate.INSTANCE);
            if(actions != null) {
                cv.put(COLUMN_ACTIONS, actions.toString());
            }
            long res = db.insert(MESSAGES_TABLE_NAME, null, cv);
            Logger.d(TAG, " new message id is "+inAppPayload.getId());
            if(res >= 0) {
                for(String rule : inAppPayload.getRules()) {
                    cv = new ContentValues();
                    cv.put(COLUMN_MESSAGE_ID, String.valueOf(inAppPayload.getId()));
                    cv.put(COLUMN_RULE_NAME, rule);
                    res = db.insert(RULES_TABLE_NAME, null, cv);
                    Logger.d(TAG, "Rule insert ID: "+res);
                    if(res < 0) {
                        throw new IOException("Failed to store rule");
                    }
                }
            }
            db.setTransactionSuccessful();
        } catch (JSONException jsone) {
            throw new IOException("Failed to store inapp", jsone);
        }
        finally {
            db.endTransaction();
            printTables();
        }
    }

    public void updateViews(InAppPayload inAppPayload) {
        Logger.d(TAG, "Update views of "+inAppPayload.getId()+" views is "+inAppPayload.getViews()+" max views is "+inAppPayload.getMaxViews());
        Logger.d(TAG, "Max views not reached - updating message");
        String[] whereArgs = new String[] {String.valueOf(inAppPayload.getId())};
        String whereClause = COLUMN_MESSAGE_ID + " = ?";
        SQLiteDatabase db =  getWritableDatabase();
        Logger.d(TAG, "Update where clause: "+whereClause);
        if(inAppPayload.getViews() == inAppPayload.getMaxViews()) {
            Logger.d(TAG, "Max views reached - deleting message");
            deleteMessageById(inAppPayload.getId());
        } else {
            Logger.d(TAG, "Max views not reached - updating message");
            ContentValues cv = new ContentValues();
            cv.put(COLUMN_VIEWS, inAppPayload.getViews());
            int res = db.update(MESSAGES_TABLE_NAME, cv, whereClause, whereArgs);
            Logger.d(TAG, "Views update result: "+res);
        }
    }

    public boolean deleteMessage(InAppPayload inAppPayload) {
        return deleteMessageById(inAppPayload.getId());
    }

    public boolean deleteMessageById(long messageId) {
        SQLiteDatabase db =  getWritableDatabase();
        try {
            db.beginTransaction();
            String[] whereArgs = {String.valueOf(messageId)};
            String condition = COLUMN_MESSAGE_ID + " = ?";
            int res = db.delete(MESSAGES_TABLE_NAME, condition, whereArgs);
            if (res >= 0) {
                res = db.delete(RULES_TABLE_NAME, condition, whereArgs);
                if (res >= 0) {
                    db.setTransactionSuccessful();
                    return true;
                }
            }
            return false;
        } finally {
            db.endTransaction();
        }
    }

    public void clearExpiredMessages() {
        long currentTime = System.currentTimeMillis();
        Cursor expiredMessagesCursor = getReadableDatabase().query(MESSAGES_TABLE_NAME, new String[] {COLUMN_MESSAGE_ID},COLUMN_EXPIRATION_DATE+" < "+currentTime, null, null, null, null);
        if(expiredMessagesCursor.getCount() > 0) {
            Logger.d(TAG, "Found expired messages: "+expiredMessagesCursor.getCount());
            while (expiredMessagesCursor.moveToNext()) {
                long messageId = Long.valueOf(expiredMessagesCursor.getString(expiredMessagesCursor.getColumnIndex(COLUMN_MESSAGE_ID)));
                Logger.d(TAG, "Deleting expired message: "+messageId);
                deleteMessageById(messageId);
            }
        }
    }


    public List<InAppPayload> getAllMessages(List<String> templates, List<String> rules, boolean matchAll, boolean onlyOne) {
        clearExpiredMessages();
        SQLiteQueryBuilder allMessagesQuery = new SQLiteQueryBuilder();
        allMessagesQuery.setTables(MESSAGES_TABLE_NAME + " INNER JOIN " + RULES_TABLE_NAME + " ON " +MESSAGES_TABLE_NAME+"."+COLUMN_MESSAGE_ID+" = "+RULES_TABLE_NAME+"."+COLUMN_MESSAGE_ID);
        List<InAppPayload> messagesResult = new LinkedList<InAppPayload>();
        SQLiteDatabase db =  getReadableDatabase();
        String currentTime = String.valueOf(System.currentTimeMillis());
        String whereClause = MESSAGES_TABLE_NAME+"."+COLUMN_EXPIRATION_DATE + " > "+currentTime+" AND "+MESSAGES_TABLE_NAME+"."+COLUMN_TRIGGER_DATE + " <= "+currentTime;
        List<String> whereArgs = new LinkedList<String>();
        if(templates != null && !templates.isEmpty()){
            whereClause+=" AND "+MESSAGES_TABLE_NAME+"."+COLUMN_TEMPLATE_NAME+" in (?";
            whereArgs.add(templates.get(0));
            for(int i = 1; i<templates.size() ; ++i) {
                whereClause+=", ?";
                whereArgs.add(templates.get(i));
            }
            whereClause+=")";
        }
        if(rules != null && !rules.isEmpty()){
            whereClause+=" AND "+RULES_TABLE_NAME+"."+COLUMN_RULE_NAME+" in (?";
            whereArgs.add(rules.get(0));
            for(int i = 1; i<rules.size() ; ++i) {
                whereClause+=", ?";
                whereArgs.add(rules.get(i));
            }
            whereClause+=")";
        }
        allMessagesQuery.setDistinct(true);
        Cursor allMessagesCursor = allMessagesQuery.query(db, MESSAGES_TABLE_COLUMNS, whereClause, whereArgs.toArray(new String[whereArgs.size()]), null, null, MESSAGES_TABLE_NAME+"."+COLUMN_TRIGGER_DATE+" ASC", (onlyOne ? "1" : null));
        while(allMessagesCursor.moveToNext()) {
            try {
                long messageId = Long.valueOf(allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_MESSAGE_ID)));
                String attribution = allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_ATTRIBUTION));
                String mailngId = allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_MAILING_ID));
                long triggerDate = allMessagesCursor.getLong(allMessagesCursor.getColumnIndex(COLUMN_TRIGGER_DATE));
                long expirationDate = allMessagesCursor.getLong(allMessagesCursor.getColumnIndex(COLUMN_EXPIRATION_DATE));
                int maxViews = allMessagesCursor.getInt(allMessagesCursor.getColumnIndex(COLUMN_MAX_VIEWS));
                int views = allMessagesCursor.getInt(allMessagesCursor.getColumnIndex(COLUMN_VIEWS));
                String templateName = allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_TEMPLATE_NAME));
                JSONObject templateContent = new JSONObject(allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_TEMPLATE)));
                String rulesStr = allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_RULES));
                JSONArray rulesJSONArray = null;
                if(rulesStr != null) {
                    rulesJSONArray = new JSONArray(rulesStr);
                }
                List<String> inAppRules = JsonUtil.fromJsonStringArray(rulesJSONArray);
                String actionsStr = allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_ACTIONS));
                JSONArray actionsJSONArray = null;
                if(actionsStr != null) {
                    actionsJSONArray = new JSONArray(actionsStr);
                }
                List<InAppAction> inAppActions = InAppPayloadJsonTemplate.InAppActionJsonTemplate.LIST_TEMPLATE.fromJSONArray(
                        actionsJSONArray,
                        InAppPayloadJsonTemplate.InAppActionJsonTemplate.INSTANCE);
                boolean matchFound = true;
                if(rules != null && matchAll) {
                    if(inAppRules != null && inAppRules.size() >= rules.size()) {
                        for(String rule : rules) {
                            if(!inAppRules.contains(rule)) {
                                matchFound = false;
                                break;
                            }
                        }
                    } else {
                        matchFound = false;
                    }
                }
                if(matchFound) {
                    messagesResult.add(new InAppPayload(messageId, attribution, new Date(triggerDate), new Date(expirationDate), inAppRules, maxViews, views, templateName, templateContent, inAppActions, mailngId));
                    if(onlyOne) {
                        break;
                    }
                }
            } catch (JSONException jsone) {

            }
        }
        return messagesResult;
    }

    public void printTables() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor allMessagesCursor = db.query(MESSAGES_TABLE_NAME, new String[] {COLUMN_MESSAGE_ID, COLUMN_ATTRIBUTION, COLUMN_MAILING_ID, COLUMN_TRIGGER_DATE, COLUMN_EXPIRATION_DATE, COLUMN_MAX_VIEWS, COLUMN_VIEWS, COLUMN_TEMPLATE_NAME, COLUMN_TEMPLATE, COLUMN_RULES, COLUMN_ACTIONS },null, null, null, null, COLUMN_TRIGGER_DATE+" ASC");
        Logger.d(TAG, "Messages: "+allMessagesCursor.getCount());
        if(allMessagesCursor.getCount() > 0) {
            while (allMessagesCursor.moveToNext()) {
                try {
                    long messageId = Long.valueOf(allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_MESSAGE_ID)));
                    String attribution = allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_ATTRIBUTION));
                    String mailngId = allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_MAILING_ID));
                    long triggerDate = allMessagesCursor.getLong(allMessagesCursor.getColumnIndex(COLUMN_TRIGGER_DATE));
                    long expirationDate = allMessagesCursor.getLong(allMessagesCursor.getColumnIndex(COLUMN_EXPIRATION_DATE));
                    int maxViews = allMessagesCursor.getInt(allMessagesCursor.getColumnIndex(COLUMN_MAX_VIEWS));
                    int views = allMessagesCursor.getInt(allMessagesCursor.getColumnIndex(COLUMN_VIEWS));
                    String templateName = allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_TEMPLATE_NAME));
                    JSONObject templateContent = new JSONObject(allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_TEMPLATE)));
                    String rulesStr = allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_RULES));
                    JSONArray rulesJSONArray = null;
                    if(rulesStr != null) {
                        rulesJSONArray = new JSONArray(rulesStr);
                    }
                    List<String> inAppRules = JsonUtil.fromJsonStringArray(rulesJSONArray);
                    String actionsStr = allMessagesCursor.getString(allMessagesCursor.getColumnIndex(COLUMN_ACTIONS));
                    JSONArray actionsJSONArray = null;
                    if(actionsStr != null) {
                        actionsJSONArray = new JSONArray(actionsStr);
                    }
                    List<InAppAction> inAppActions = InAppPayloadJsonTemplate.InAppActionJsonTemplate.LIST_TEMPLATE.fromJSONArray(
                            actionsJSONArray,
                            InAppPayloadJsonTemplate.InAppActionJsonTemplate.INSTANCE);
                    Logger.d(TAG, (new InAppPayload(messageId, attribution, new Date(triggerDate), new Date(expirationDate), inAppRules, maxViews, views, templateName, templateContent, inAppActions, mailngId)).toString());
                } catch (JSONException jsone) {

                }
            }
        }
        Cursor allRulesCursor = db.query(RULES_TABLE_NAME, new String[] {COLUMN_MESSAGE_ID, COLUMN_RULE_NAME},null, null, null, null, COLUMN_MESSAGE_ID+" ASC");
        Logger.d(TAG, "Rules: "+allRulesCursor.getCount());
        if(allRulesCursor.getCount() > 0) {
            while (allRulesCursor.moveToNext()) {
                long messageId = Long.valueOf(allRulesCursor.getString(allRulesCursor.getColumnIndex(COLUMN_MESSAGE_ID)));
                String ruleName = allRulesCursor.getString(allRulesCursor.getColumnIndex(COLUMN_RULE_NAME));
                Logger.d(TAG, messageId + "\t" + ruleName);
            }
        }
    }


}

