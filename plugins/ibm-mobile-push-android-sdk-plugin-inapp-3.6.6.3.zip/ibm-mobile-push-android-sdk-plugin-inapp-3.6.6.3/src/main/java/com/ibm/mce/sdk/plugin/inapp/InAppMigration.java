/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2017.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */

package com.ibm.mce.sdk.plugin.inapp;

import com.ibm.mce.sdk.util.Logger;

import io.realm.Realm;
import io.realm.RealmMigration;
import io.realm.internal.ColumnType;
import io.realm.internal.Table;

/**
 * This class migrates the realm db from 3.6.3.0 and below to 3.6.4.0
 */
public class InAppMigration implements RealmMigration {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2017, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";



    private static final java.lang.String TAG = "InAppMigration";

    /**
     * Runs the migration
     * @param realm The realm instance
     * @param version The realm db version
     * @return The realm db version
     */
    @Override
    public long execute(Realm realm, long version) {
        Logger.d(TAG,"Realm migration");
        Table table = realm.getTable(InAppMessageRealm.class);
        table.addColumn(ColumnType.STRING, "mailingId");
        return version;
    }
}
