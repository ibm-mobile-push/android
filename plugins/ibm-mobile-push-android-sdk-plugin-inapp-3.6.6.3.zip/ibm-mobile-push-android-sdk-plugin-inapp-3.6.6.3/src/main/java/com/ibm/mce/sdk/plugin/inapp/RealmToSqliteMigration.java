/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2017.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */package com.ibm.mce.sdk.plugin.inapp;

import android.content.Context;

import com.ibm.mce.sdk.util.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class RealmToSqliteMigration {
    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    private static final String TAG = "RealmToSqliteMigration";

    public static void migrateRealmToSqlite(Context context) {
        List<InAppMessage> realmMessages = RealmInAppStorage.find(context, RealmInAppStorage.Condition.ANY, null, null, false);
        if(realmMessages != null && !realmMessages.isEmpty()) {
            long currentTime = System.currentTimeMillis();
            int index =0;
            for(InAppMessage realmMessage : realmMessages) {
                if(realmMessage.getExpirationDate().getTime()>currentTime) {
                    List<Action> realmActions = realmMessage.getActions();
                    List<InAppAction> sqlliteActions = null;
                    if(realmActions != null) {
                        sqlliteActions = new ArrayList<InAppAction>(realmActions.size());
                        for(Action realmAction : realmActions) {
                            sqlliteActions.add(new InAppAction(realmAction.getName(), realmAction.getValue()));
                        }
                    }
                    InAppPayload inAppPayload = new InAppPayload(currentTime+index, realmMessage.getAttribution(), realmMessage.getTriggerDate(), realmMessage.getExpirationDate(), realmMessage.getRules(), realmMessage.getMaxViews(), 0, realmMessage.getTemplateName(), realmMessage.getTemplateContent(), sqlliteActions, realmMessage.getMailingId());
                    index++;
                    try {
                        InAppMessagesDatabaseHelper.getInAppMessagesDatabaseHelper(context).addMessage(inAppPayload);
                        Logger.d(TAG, "Migrated inApp message: "+realmMessage.getId()+" to "+inAppPayload.getId());
                    } catch(IOException ioe) {
                        Logger.e(TAG, "Failed to migrate inapp message: "+realmMessage.getId(), ioe);
                    }
                }
            }
        }
    }
}
