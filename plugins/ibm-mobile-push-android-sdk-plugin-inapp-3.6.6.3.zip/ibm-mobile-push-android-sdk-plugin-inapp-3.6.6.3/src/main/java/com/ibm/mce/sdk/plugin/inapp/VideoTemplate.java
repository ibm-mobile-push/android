/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.ibm.mce.sdk.util.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * This is the inApp video template
 */
public class VideoTemplate extends BaseInAppTemplate {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";
    public static final String TITLE_KEY = "title";
    public static final String TEXT_KEY = "text";
    public static final String VIDEO_KEY = "video";


    /**
     * No resources are created
     * @param context The application's context
     * @param message The inapp message
     * @return null
     */
    @Override
    public Map<String, Object> createOfflineResources(Context context, InAppPayload message) {
        return null;
    }

    /**
     * Resources are not required
     * @return false
     */
    @Override
    public boolean requiresOfflineResources() {
        return false;
    }

    @Override
    protected void setupArguments(Context context, InAppPayload message, Bundle arguments, Map<String, Object> offlineResources) throws JSONException {
        arguments.putString(TITLE_KEY, message.getTemplateContent().optString(TITLE_KEY));
        arguments.putString(TEXT_KEY, message.getTemplateContent().optString(TEXT_KEY));
        arguments.putString(VIDEO_KEY, message.getTemplateContent().optString(VIDEO_KEY));
    }

    @Override
    protected String getFragmentLayoutId() {
        return "mce-video";
    }

    @Override
    protected InAppFragment createFragment() {
        return new VideoFragment();
    }

}

