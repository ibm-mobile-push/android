/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */

package com.ibm.mce.sdk.plugin.inapp;

import android.content.Context;
import android.os.Bundle;

import com.ibm.mce.sdk.api.MceSdk;
import com.ibm.mce.sdk.api.OperationCallback;
import com.ibm.mce.sdk.api.OperationResult;
import com.ibm.mce.sdk.api.attribute.Attribute;
import com.ibm.mce.sdk.api.attribute.StringAttribute;
import com.ibm.mce.sdk.api.event.Event;
import com.ibm.mce.sdk.notification.MceNotificationActionImpl;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * This class is responsible for sending the inApp events
 */
public class InAppEvents {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n� Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    /**
     * The inApp message type value
     */
    public static final String IN_APP_MESSAGE_TYPE = "inAppMessage";


    /**
     * Send inApp message opened event
     * @param context The application's context
     * @param message The opened message
     */
    public static void sendInAppMessageOpenedEvent(final Context context,InAppPayload message) {
        List<Attribute> eventAttributes = new LinkedList<Attribute>();

        final Event event = new Event(IN_APP_MESSAGE_TYPE, "messageOpened", new Date(), eventAttributes, message.getAttribution(), message.getMailingId());
        MceSdk.getEventsClient(false).sendEvent(context, event, new OperationCallback<Event>() {
            @Override
            public void onSuccess(Event event, OperationResult result) {

            }

            @Override
            public void onFailure(Event event, OperationResult result) {
                MceSdk.getQueuedEventsClient().sendEvent(context, event);
            }
        });
    }

    /**
     * Send inApp message action taken event
     * @param context The application's context
     * @param actionType The action's type
     * @param payload The action's payload
     * @param attribution The action's attribution
     * @param mailingId The action's mailing id
     */
    public static void sendInAppMessageActionTakenEvent(final Context context,String actionType, Bundle payload, String attribution, String mailingId) {
        String name = actionType;
        List<Attribute> eventAttributes = new LinkedList<Attribute>();
        MceNotificationActionImpl.ClickEventDetails clickEventDetails = MceNotificationActionImpl.getClickEventDetails(actionType);
        if(clickEventDetails != null) {
            name = clickEventDetails.eventName;
            String value = payload.getString("value");
            eventAttributes.add(new StringAttribute(clickEventDetails.valueName, value));
        } else {
            for(String key : payload.keySet()) {
                eventAttributes.add(new StringAttribute(key, payload.getString(key)));
            }
        }

        final Event event = new Event(IN_APP_MESSAGE_TYPE, name, new Date(), eventAttributes, attribution, mailingId);
        MceSdk.getEventsClient(false).sendEvent(context, event , new OperationCallback<Event>() {
            @Override
            public void onSuccess(Event event, OperationResult result) {

            }

            @Override
            public void onFailure(Event event, OperationResult result) {
                MceSdk.getQueuedEventsClient().sendEvent(context, event);
            }
        });
    }
}

