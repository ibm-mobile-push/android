/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v4.app.FragmentManager;

import com.ibm.mce.sdk.util.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * This class manages inapp messages
 */
public class InAppManager {

    public static final String COPYRIGHT =
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";
    private static final String TAG = "InAppManager";


    /**
     * Show the first inapp message. The message can be the first of all the messages or it can be the first of messages with a given key value
     *
     * @param context         The application's context
     * @param key             The key for a key value search. For no search use null
     * @param values          The value for a key value search. For no search use null
     * @param fragmentManager The fragment manager that contains the fragment on which the view will be displayed
     * @param containerViewId The id of the view that the message will be displayed on
     */
    public static void show(final Context context, InAppStorage.KeyName key, List<String> values, final FragmentManager fragmentManager, final @IdRes int containerViewId) {
        checkMigration(context);
        final InAppPayload inAppPayload = InAppStorage.findFirst(context, key, values);
        if (inAppPayload == null) return;

        Class<? extends InAppTemplate> templateClass = InAppTemplateRegistry.getInstance().get(inAppPayload.getTemplateName());
        if (templateClass == null) return;
        try {
            final InAppTemplate template = templateClass.newInstance();
            if(!template.requiresOfflineResources()) {
                template.show(context, fragmentManager, containerViewId, inAppPayload, null); // pass InAppMessage
            } else {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Map<String, Object> resources = template.createOfflineResources(context, inAppPayload);
                        template.show(context, fragmentManager, containerViewId, inAppPayload, resources); // pass InAppMessage
                    }
                }).start();
            }
            InAppEvents.sendInAppMessageOpenedEvent(context, inAppPayload);
            InAppStorage.updateMaxViews(context, inAppPayload);
        } catch (Exception e) {
            Logger.e(TAG, "Error while showing the InApp Message. Details: " + e.getMessage(), e);
        }
    }

    /**
     * Show the first inapp message from all the inapp messages.
     *
     * @param context         The application's context
     * @param fragmentManager The fragment manager that contains the fragment on which the view will be displayed
     * @param containerViewId The id of the view that the message will be displayed on
     */
    public static void show(Context context, FragmentManager fragmentManager, @IdRes int containerViewId) {
        show(context, null, null, fragmentManager, containerViewId);
    }

    /**
     * Extracts an inapp segement of the notification if exists and adds it to the database
     *
     * @param context     The application's context
     * @param msgExtras   The bundle that contains the notification
     * @param attribution The attribution for the inapp message
     * @param mailingId The notification mailing id
     */
    public static void handleNotification(Context context, Bundle msgExtras, String attribution, String mailingId) {
        if (!msgExtras.containsKey("inApp")) {
            Logger.d(TAG, "inApp payload not found");
            return;
        }
        try {
            checkMigration(context);
            String inAppJSON = msgExtras.getString("inApp");
            Logger.d(TAG,"processing inApp payload: "+inAppJSON);
            InAppPayload inAppPayload = InAppPayloadJsonTemplate.inAppPayloadFromJSON(new JSONObject(inAppJSON));
            inAppPayload.setMceContext(attribution, mailingId);
            InAppStorage.save(context, inAppPayload);
            Logger.d(TAG,"Saved inApp payload: "+inAppPayload);
        } catch (JSONException jsone) {
            Logger.e(TAG, "Error while parsing the InApp Message. Details: " + jsone.getMessage(), jsone);
        } catch (IOException ioe) {
            Logger.e(TAG, "Error while parsing the InApp Message. Details: " + ioe.getMessage(), ioe);
        }

    }

    /**
     * Deletes an inapp message
     * @param context The application's context
     * @param messageId The inapp message id
     */
    public static void delete(Context context, long messageId) {
        InAppStorage.delete(context, messageId);
    }

    /**
     * This method checks if old realm db is needed for migration and migrates if it is
     * @param context The application's context
     */
    public static void checkMigration(Context context) {
        if(!InAppPreferences.isSqliteActivated(context)) {
            try {
                Class.forName("io.realm.RealmObject");
                RealmToSqliteMigration.migrateRealmToSqlite(context);
                InAppPreferences.setSqliteActivated(context);
            } catch (ClassNotFoundException cnfe) {
                Logger.d(TAG,"Realm not found");
            }
        }
    }

    /**
     * This method clears all inapp messages
     * @param context The application's context
     */
    public static void clearData(Context context) {
        Logger.d(TAG, "Clearing inApp data");
        InAppStorage.clear(context);
    }


}
