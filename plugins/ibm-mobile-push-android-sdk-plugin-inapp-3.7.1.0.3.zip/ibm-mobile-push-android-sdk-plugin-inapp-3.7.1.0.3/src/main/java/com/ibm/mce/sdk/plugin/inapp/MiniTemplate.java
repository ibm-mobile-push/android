/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.ibm.mce.sdk.util.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.Map;

/**
 * This is the mini inApp template
 */
public class MiniTemplate extends BaseInAppTemplate {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    static final String ORIENTATION_TOP="top";
    static final String ORIENTATION_BOTTOM="bottom";
    static final String ICON_KEY = "icon";
    static final String COLOR_KEY = "color";
    static final String TEXT_KEY = "text";
    static final String ORIENTATION_KEY = "orientation";
    static final String FOREGROUND_KEY = "foreground";
    static final String DURATION_KEY = "duration";

    /**
     * No reslources are needed
     * @return false
     */
    @Override
    public boolean requiresOfflineResources() {
        return false;
    }

    /**
     * No resources aer created
     * @param context The application's context
     * @param message The inapp message
     * @return null
     */
    @Override
    public Map<String, Object> createOfflineResources(Context context, InAppPayload message) {
        return null;
    }

    @Override
    protected void setupArguments(Context context, InAppPayload message, Bundle arguments, Map<String, Object> offlineResources) throws JSONException {
        arguments.putString(ICON_KEY, message.getTemplateContent().getString(ICON_KEY));
        arguments.putString(COLOR_KEY, message.getTemplateContent().getString(COLOR_KEY));
        arguments.putString(TEXT_KEY, message.getTemplateContent().getString(TEXT_KEY));
        arguments.putString(ORIENTATION_KEY, message.getTemplateContent().optString(ORIENTATION_KEY, ORIENTATION_BOTTOM));
        arguments.putString(FOREGROUND_KEY, message.getTemplateContent().optString(FOREGROUND_KEY, null));
        arguments.putInt(DURATION_KEY, message.getTemplateContent().optInt(DURATION_KEY, 5));

    }

    @Override
    protected String getFragmentLayoutId() {
        return "mce-mini";
    }

    @Override
    protected InAppFragment createFragment() {
        return new MiniFragment();
    }

}

