/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.content.Context;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmQuery;
import io.realm.RealmResults;
import io.realm.exceptions.RealmMigrationNeededException;

class RealmInAppStorage {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    // TODO change it to run off the main thread.

    private static final String DB_NAME = "mce-inapp.realm";

    public enum KeyName {

        TEMPLATE("template"), RULE("rules.val");

        private final String name;

        private KeyName(String name) {
            this.name = name;
        }

        public String toString() {
            return name;
        }

    }

    public enum Condition {
        ANY, ALL;
    }

    public static List<InAppMessage> find(Context context, Condition condition, KeyName key, List<String> values, boolean findFirst) {
        Realm realm;
        try {
            realm = Realm.getInstance(context, DB_NAME);
        } catch (RealmMigrationNeededException rmne) {
            Realm.migrateRealmAtPath(context.getFileStreamPath(DB_NAME).getPath(), new InAppMigration());
            realm = Realm.getInstance(context, DB_NAME);
        }

        RealmQuery<InAppMessageRealm> query = realm.where(InAppMessageRealm.class);

        addConditionGroup(query, condition, key, values);
        ArrayList<InAppMessage> messages = new ArrayList<InAppMessage>();
        ArrayList<InAppMessageRealm> messagesForDelete = new ArrayList<InAppMessageRealm>();

        RealmResults<InAppMessageRealm> realmResult = query.findAll();
        if(!realmResult.isEmpty()) {
            Date now = new Date();
            realmResult.sort("triggerDate");
            for (InAppMessageRealm messageRealm : realmResult) {
                if(messageRealm.getMaxViews() == 0 || messageRealm.getExpirationDate().before(now)) {
                    messagesForDelete.add(messageRealm);
                } else if(messageRealm.getTriggerDate().before(now)) {
                    if (!findFirst || messages.isEmpty()) {
                        messages.add(new InAppMessage(messageRealm));
                    }
                }
            }
        }
        if(!messagesForDelete.isEmpty()) {
            try {
                realm.beginTransaction();
                for (InAppMessageRealm messageRealm : messagesForDelete) {
                    messageRealm.removeFromRealm();
                }
            } finally {
                realm.commitTransaction();
            }
        }
        return messages;
    }


    private static void addConditionGroup(RealmQuery<InAppMessageRealm> query, Condition condition, KeyName key, List<String> values) {
        if (key == null || values == null) return;
        if (condition == null) condition = Condition.ANY;

        query.beginGroup();
        for (int i = 0; i < values.size(); i++) {
            if (i == 0 || condition.equals(Condition.ALL))
                query.equalTo(key.toString(), values.get(i));
            else query.or().equalTo(key.toString(), values.get(i));
        }
        query.endGroup();

    }

    public static List<InAppMessage> find(Context context, KeyName key, List<String> values) {
        return find(context, Condition.ANY, key, values, false);
    }

    public static List<InAppMessage> find(Context context, Condition condition, KeyName key, List<String> values) {
        return find(context, condition, key, values, false);
    }


    public static InAppMessage findFirst(Context context, KeyName key, List<String> values) {
        List<InAppMessage> messages = find(context, Condition.ANY, key, values, true);
        if(!messages.isEmpty()) {
            return find(context, Condition.ANY, key, values, true).get(0);
        } else {
            return null;
        }
    }

    public static InAppMessage findFirst(Context context, Condition condition, KeyName key, List<String> values) {
        return find(context, condition, key, values, true).get(0);
    }

    public static void save(Context context, final InAppMessageRealm inAppMessageRealm) {
        Realm.getInstance(context, DB_NAME).executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm.copyToRealm(inAppMessageRealm);
            }
        });
    }

    public static void updateMaxViews(Context context, final InAppMessageRealm inAppMessageRealm) {
        final Realm realm = Realm.getInstance(context, DB_NAME);
        try {
            realm.beginTransaction();
            inAppMessageRealm.setMaxViews(inAppMessageRealm.getMaxViews() - 1);
            realm.copyToRealmOrUpdate(inAppMessageRealm);
        } finally {
            realm.commitTransaction();
        }
    }

    public static void delete(Context context, int id) {
        final Realm realm = Realm.getInstance(context, DB_NAME);

        RealmQuery<InAppMessageRealm> query = realm.where(InAppMessageRealm.class);
        ArrayList<InAppMessageRealm> messagesForDelete = new ArrayList<InAppMessageRealm>();
        query.equalTo("id", id);
        RealmResults<InAppMessageRealm> realmResult = query.findAll();
        if(!realmResult.isEmpty()) {
            for (InAppMessageRealm messageRealm : realmResult) {
                messagesForDelete.add(messageRealm);
            }
        }
        if(!messagesForDelete.isEmpty()) {
            try {
                realm.beginTransaction();
                for (InAppMessageRealm messageRealm : messagesForDelete) {
                    messageRealm.removeFromRealm();
                }
            } finally {
                realm.commitTransaction();
            }
        }

    }

    public static int getNextPrimaryKey(Context context) {
        Realm realm = Realm.getInstance(context, DB_NAME);
        return ((int)realm.where(InAppMessageRealm.class).maximumInt("id")) + 1;
    }


}
