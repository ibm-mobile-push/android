/*
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2017.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;


import com.ibm.mce.sdk.util.Iso8601;
import com.ibm.mce.sdk.util.json.JsonUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;
import java.util.List;

/**
 * This is the inApp message class
 */
public class InAppPayload {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    private final String id;
    private String contentId;
    private String attribution;
    private String mailingId;
    private final Date triggerDate;
    private final Date expirationDate;
    private final List<String> rules;
    private final int maxViews;
    private int views;
    private final String templateName;
    private final JSONObject templateContent;
    private final List<InAppAction> actions;
    private boolean fromPull;



    InAppPayload(String id, String contentId, String attribution, Date triggerDate, Date expirationDate, List<String> rules, int maxViews, int views, String templateName, JSONObject templateContent, List<InAppAction> actions, String mailingId, boolean fromPull) {
        this.id = id;
        this.contentId = contentId;
        this.attribution = attribution;
        this.triggerDate = triggerDate;
        this.expirationDate = expirationDate;
        this.rules = rules;
        this.maxViews = maxViews;
        this.views = views;
        this.templateName = templateName;
        this.templateContent = templateContent;
        this.actions = actions;
        this.mailingId = mailingId;
        this.fromPull = fromPull;
    }

    /**
     * Retrieves the inApp message id
     * @return The id
     */
    public String getId() {
        return id;
    }

    /**
     * Retrieves the inApp message content id
     * @return
     */
    public String getContentId() {
        return contentId;
    }

    /**
     * Retrieves the inApp message attribution
     * @return The attribution
     */
    public String getAttribution() {
        return attribution;
    }

    /**
     * Retrieves the inApp message mailing id
     * @return The mailing id
     */
    public String getMailingId() {
        return mailingId;
    }

    /**
     * Retrieves the inApp message trigger date
     * @return The trigger date
     */
    public Date getTriggerDate() {
        return triggerDate;
    }

    /**
     * Retrieves the inApp message expiration date
     * @return The expiration date
     */
    public Date getExpirationDate() {
        return expirationDate;
    }

    /**
     * Retrieves the inApp message rules
     * @return The rules
     */
    public List<String> getRules() {
        return rules;
    }

    /**
     * Retrieves the inApp message maxviews count
     * @return The max views count
     */
    public int getMaxViews() {
        return maxViews;
    }

    /**
     * Retrieves the inApp message views count
     * @return The views count
     */
    public int getViews() {
        return views;
    }

    void setViews(int views) {
        this.views = views;
    }

    /**
     * Retrieves the inApp message template name
     * @return The template name
     */
    public String getTemplateName() {
        return templateName;
    }

    /**
     * Retrieves the inApp message template content
     * @return The template content
     */
    public JSONObject getTemplateContent() {
        return templateContent;
    }

    /**
     * Retrieves the inApp message actions
     * @return The actions
     */
    public List<InAppAction> getActions() {
        return actions;
    }

    /**
     * Checks if the inApp message is from a pull request
     * @return
     */
    public boolean isFromPull() {
        return fromPull;
    }

    /**
     * Add to the view count of the message
     */
    public void toggleViewed() {
        views++;
    }

    void setMceContext(String attribution, String mailingId) {
        this.attribution = attribution;
        this.mailingId = mailingId;
    }

    /**
     * Retrieves a string representation of the message
     * @return
     */
    @Override
    public String toString() {
        try {
            return "InAppPayload{" +
                    "id=" + id +
                    ", contentId='" + contentId + '\'' +
                    ", attribution='" + attribution + '\'' +
                    ", mailingId='" + mailingId + '\'' +
                    ", triggerDate=" + Iso8601.toPrintableString(triggerDate) +" ("+triggerDate.getTime()+")"+
                    ", expirationDate=" + Iso8601.toPrintableString(expirationDate) +" ("+expirationDate.getTime()+")"+
                    ", rules=" + JsonUtil.toJsonStringArray(rules) +
                    ", maxViews=" + maxViews +
                    ", views=" + views +
                    ", templateName='" + templateName + '\'' +
                    ", templateContent=" + templateContent +
                    ", actions=" + InAppPayloadJsonTemplate.InAppActionJsonTemplate.LIST_TEMPLATE.toJsonArray(actions, InAppPayloadJsonTemplate.InAppActionJsonTemplate.INSTANCE) +
                    '}';
        } catch (JSONException jsone) {
            return jsone.getMessage();
        }
    }
}
