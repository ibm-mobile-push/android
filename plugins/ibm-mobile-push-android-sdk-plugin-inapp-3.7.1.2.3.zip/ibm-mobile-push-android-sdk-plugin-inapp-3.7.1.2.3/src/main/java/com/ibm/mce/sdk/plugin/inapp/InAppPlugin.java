/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2018.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.content.Context;

import com.ibm.mce.sdk.MceServerUrl;
import com.ibm.mce.sdk.api.MceSdk;
import com.ibm.mce.sdk.api.registration.RegistrationDetails;
import com.ibm.mce.sdk.plugin.Plugin;
import com.ibm.mce.sdk.util.HttpHelper;
import com.ibm.mce.sdk.util.Iso8601;
import com.ibm.mce.sdk.util.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Date;
import java.util.List;

public class InAppPlugin implements Plugin {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2018, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    private static final String TAG = "InAppPlugin";

    private static class InAppUpdateUrl extends MceServerUrl {
        static final String INBOX_PART = "inbox";
        static final String STATUS_PART = "status";


        final String getInAppUpdateUrl(String baseUrl, Context context) {
            RegistrationDetails registrationDetails = MceSdk.getRegistrationClient().getRegistrationDetails(context);
            return buildURL(baseUrl, VERSION_PART, APPS_PART, MceSdk.getRegistrationClient().getAppKey(context), INBOX_PART, USERS_PART, registrationDetails.getUserId(), CHANNELS_PART, registrationDetails.getChannelId(), STATUS_PART);

        }

        final String getInAppUpdateUrl(Context context) {
            return getInAppUpdateUrl(getBaseUrl(), context);
        }
    }

    public static void updateInAppMessage(final Context context, final InAppPayload inAppPayload) {
        (new Thread() {
            @Override
            public void run() {
                Logger.d(TAG, "inApp message state update is performed for: "+inAppPayload);
                HttpHelper.Response response = null;
                try {
                    JSONObject updatePayload = new JSONObject();
                    updatePayload.put("inAppMessageId", inAppPayload.getId());
                    updatePayload.put("numViews", inAppPayload.getViews());
                    updatePayload.put("maxViews", inAppPayload.getMaxViews());
                    updatePayload.put("timestamp", Iso8601.toString(new Date(System.currentTimeMillis())));
                    JSONArray updates = new JSONArray();
                    updates.put(updatePayload);
                    JSONObject payload = new JSONObject();
                    payload.put("inAppUpdates", updates);
                    String inAppUpdateUrl = new InAppUpdateUrl().getInAppUpdateUrl(context);
                    response = HttpHelper.postJson(inAppUpdateUrl, payload.toString());
                    if (response.getHttpResponseCode() == 202) {
                       Logger.d(TAG, "inApp message update succeeded for: "+inAppPayload);
                    } else {
                        Logger.e(TAG, "Failed updating inApp message: " + response.getHttpResponseCode() + " " + response.getHttpResponseMessage());
                    }
                } catch (Exception e) {
                    Logger.e(TAG, "Failed updating inApp message: " + response.getHttpResponseCode() + " " + response.getHttpResponseMessage(), e);
                }
            }
        }).start();
    }

    @Override
    public void sync(Context context, JSONObject syncData) {
        try {
            JSONArray inAppMessages = syncData.optJSONArray("inAppMessages");
            if(inAppMessages != null) {
                Logger.d(TAG, "Processing inApp sync data: "+inAppMessages);
                List<InAppPayload> messages = (new InAppPayloadJsonTemplate.InAppPayloadListTemplate()).fromJSONArray(inAppMessages);
                for(InAppPayload inAppMessage : messages) {
                    try {
                        InAppStorage.update(context, inAppMessage, true);
                    } catch (IOException ioe) {
                        Logger.e(TAG,"Failed to update inApp message", ioe);
                    }
                }
            } else {
                Logger.d(TAG, "No inApp sync data found");
            }
        } catch (JSONException jsone) {
            Logger.e(TAG,"Failed to load inApp messages sync data", jsone);
        }
    }

    @Override
    public void clearData(Context context) {
        Logger.d(TAG,"Clearing inApp data");
        InAppStorage.clear(context);
    }
}
