/*
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2018.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.content.Context;

import com.ibm.mce.sdk.MceServerUrl;
import com.ibm.mce.sdk.api.MceSdk;
import com.ibm.mce.sdk.api.registration.RegistrationDetails;
import com.ibm.mce.sdk.plugin.Plugin;
import com.ibm.mce.sdk.util.HttpHelper;
import com.ibm.mce.sdk.util.Iso8601;
import com.ibm.mce.sdk.util.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Date;
import java.util.List;

public class InAppPlugin implements Plugin {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2018, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    private static final String TAG = "InAppPlugin";

    private static class InAppUpdateUrl extends MceServerUrl {
        static final String INBOX_PART = "inbox";
        static final String STATUS_PART = "status";


        final String getInAppUpdateUrl(String baseUrl, Context context) {
            RegistrationDetails registrationDetails = MceSdk.getRegistrationClient().getRegistrationDetails(context);
            return buildURL(baseUrl, VERSION_PART, APPS_PART, MceSdk.getRegistrationClient().getAppKey(context), INBOX_PART, USERS_PART, registrationDetails.getUserId(), CHANNELS_PART, registrationDetails.getChannelId(), STATUS_PART);

        }

        final String getInAppUpdateUrl(Context context) {
            return getInAppUpdateUrl(getBaseUrl(), context);
        }
    }

    private static final Object INAPP_STATUS_UPDATE_SYNC = new Object();

    public static void updateInAppMessage(final Context context, final InAppPayload inAppPayload) {
        (new Thread() {
            @Override
            public void run() {
                synchronized (INAPP_STATUS_UPDATE_SYNC) {
                    Logger.d(TAG, "inApp message state update is performed for: " + inAppPayload);
                    HttpHelper.Response response = null;
                    try {
                        JSONArray updates = new JSONArray();
                        String inappStatusUpdatePayload = InAppPreferences.getInAppStatusUpdatePayload(context);
                        if(inappStatusUpdatePayload != null) {
                            updates = new JSONArray(inappStatusUpdatePayload);
                        }
                        JSONObject updatePayload = new JSONObject();
                        updatePayload.put("inAppMessageId", inAppPayload.getId());
                        updatePayload.put("numViews", inAppPayload.getViews());
                        updatePayload.put("maxViews", inAppPayload.getMaxViews());
                        updatePayload.put("timestamp", Iso8601.toString(new Date(System.currentTimeMillis())));

                        updates.put(updatePayload);
                        JSONObject payload = new JSONObject();
                        payload.put("inAppUpdates", updates);
                        InAppPreferences.setInAppStatusUpdatePayload(context, payload.toString());
                        sendInAppStatusUpdate(context);
                    } catch (Exception e) {
                        Logger.e(TAG, "Failed to send inapp status update" + (response != null ? response.getHttpResponseCode() + " " + response.getHttpResponseMessage() : "null response"), e);
                    }
                }
            }
        }).start();
    }

    private static boolean sendInAppStatusUpdate(Context context) throws IOException {
        synchronized (INAPP_STATUS_UPDATE_SYNC) {
            String payloadString = InAppPreferences.getInAppStatusUpdatePayload(context);
            if(payloadString == null) {
                return true;
            }
            String inAppUpdateUrl = new InAppUpdateUrl().getInAppUpdateUrl(context);
            HttpHelper.Response response = HttpHelper.postJson(inAppUpdateUrl, payloadString);
            if (response != null && response.getHttpResponseCode() == 202) {
                Logger.d(TAG, "inApp status update succeeded for: " + payloadString);
                InAppPreferences.setInAppStatusUpdatePayload(context, null);
                return true;
            } else {
                Logger.e(TAG, "Failed updating inApp status: " + payloadString + " " + (response != null ? response.getHttpResponseCode() + " " + response.getHttpResponseMessage() : "null response"));
                return false;
            }
        }
    }

    private static void sendInAppStatusUpdateInNewThread(final Context context)  {
        (new Thread() {
            @Override
            public void run() {
                try {
                    sendInAppStatusUpdate(context);
                } catch (Exception e) {
                    Logger.e(TAG, "Failed to send inapp status update");
                }
            }
        }).start();
    }

    @Override
    public void sync(Context context, JSONObject syncData) {
        try {
            JSONArray inAppMessages = syncData.optJSONArray("inAppMessages");
            if(inAppMessages != null) {
                Logger.d(TAG, "Processing inApp sync data: "+inAppMessages);
                List<InAppPayload> messages = (new InAppPayloadJsonTemplate.InAppPayloadListTemplate()).fromJSONArray(inAppMessages);
                for(InAppPayload inAppMessage : messages) {
                    try {
                        InAppStorage.update(context, inAppMessage, true);
                    } catch (IOException ioe) {
                        Logger.e(TAG,"Failed to update inApp message", ioe);
                    }
                }
            } else {
                Logger.d(TAG, "No inApp sync data found");
            }
        } catch (JSONException jsone) {
            Logger.e(TAG,"Failed to load inApp messages sync data", jsone);
        }
    }

    @Override
    public void clearData(Context context) {
        Logger.d(TAG,"Clearing inApp data");
        InAppStorage.clear(context);
    }

    @Override
    public boolean sendStatusUpdates(Context context, boolean newThread) {
        if(newThread) {
            sendInAppStatusUpdateInNewThread(context);
            return false;
        } else {
            try {
                return sendInAppStatusUpdate(context);
            } catch (Exception e) {
                Logger.e(TAG, "Failed to send inApp status update", e);
                return false;
            }
        }
    }
}
