/*
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2017.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inapp;

import android.content.Context;

import com.ibm.mce.sdk.Preferences;
import com.ibm.mce.sdk.util.Logger;

class InAppPreferences extends Preferences {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    private static final String SQLITE_ACTIVATED_FLAG = "sqliteActivated";
    private static final String TAG = "InAppPreferences";

    public static boolean isSqliteActivated(Context context) {
        return getBoolean(context, SQLITE_ACTIVATED_FLAG, false);
    }

    public static void setSqliteActivated(Context context) {
        setBoolean(context, SQLITE_ACTIVATED_FLAG, true);
    }

    private static final String INAPP_STATUS_UPDATE_PAYLOAD = "inAppStatusUpdatePayload";


    public static String getInAppStatusUpdatePayload(Context context) {
        return getString(context, INAPP_STATUS_UPDATE_PAYLOAD, null);
    }

    public static void setInAppStatusUpdatePayload(Context context, String payload) {
        setString(context, INAPP_STATUS_UPDATE_PAYLOAD, payload);
        Logger.d(TAG,"Setting inApp status payload to "+payload);
    }
}
