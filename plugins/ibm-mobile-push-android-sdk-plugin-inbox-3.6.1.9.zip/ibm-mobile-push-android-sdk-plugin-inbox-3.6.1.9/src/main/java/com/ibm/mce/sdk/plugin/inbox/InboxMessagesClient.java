/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.ibm.mce.sdk.MceServerUrl;
import com.ibm.mce.sdk.api.Endpoint;
import com.ibm.mce.sdk.api.MceSdk;
import com.ibm.mce.sdk.api.OperationCallback;
import com.ibm.mce.sdk.api.OperationResult;
import com.ibm.mce.sdk.api.registration.RegistrationDetails;;
import com.ibm.mce.sdk.notification.NotificationsUtility;
import com.ibm.mce.sdk.util.HttpHelper;
import com.ibm.mce.sdk.util.Iso8601;
import com.ibm.mce.sdk.util.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class InboxMessagesClient {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    public static final String INBOX_UPDATE_ACTION = "com.ibm.mce.sdk.plugin.inbox.UPDATE";

    private static final Executor EXECUTOR = Executors.newSingleThreadExecutor();
    private static final String TAG = "InboxMessagesClient";

    private static final Map<String, Bundle> MESSAGE_ID_TO_BUNDLE = new HashMap<String, Bundle>();

    public static void showNotificationWhenMessageArrives(String messageId, Bundle bundle) {
        synchronized (MESSAGE_ID_TO_BUNDLE) {
            MESSAGE_ID_TO_BUNDLE.put(messageId, bundle);
        }
    }

    static class InboxSyncUrl extends MceServerUrl {

        static final String INBOX_PART = "inbox";
        static final String STATUS_PART = "status";

        public  final String getInboxSyncUrl(String baseUrl, Context context) {
            RegistrationDetails registrationDetails = MceSdk.getRegistrationClient().getRegistrationDetails(context);
            return buildURL(baseUrl, APPS_PART, MceSdk.getRegistrationClient().getAppKey(context), INBOX_PART, USERS_PART, registrationDetails.getUserId(), CHANNELS_PART, registrationDetails.getChannelId());
        }

        public  final String getInboxUpdatesUrl(String baseUrl, Context context) {
            RegistrationDetails registrationDetails = MceSdk.getRegistrationClient().getRegistrationDetails(context);
            return buildURL(baseUrl, APPS_PART, MceSdk.getRegistrationClient().getAppKey(context), INBOX_PART, USERS_PART, registrationDetails.getUserId(), CHANNELS_PART, registrationDetails.getChannelId(), STATUS_PART);
        }

    }

    /**
     * Sets the message state as read.
     * @param context The application's context
     * @param message The message to set as read
     * @return 1 for successful setting, 0 for no setting
     */
    public static int setMessageRead(Context context, RichContent message) {
        return setMessageReadById(context, message.getMessageId());
    }

    /**
     * Sets the message state as read.
     * @param context The application's context
     * @param messageId The id of the message to set as read
     * @return 1 for successful setting, 0 for no setting
     */
    public static int setMessageReadById(Context context, String messageId) {
        int res = RichContentDatabaseHelper.getRichContentDatabaseHelper(context).setMessageReadById(messageId);
        updateReadState(context, messageId, true, new OperationCallback<String>() {
            @Override
            public void onSuccess(String messageId, OperationResult result) {

            }

            @Override
            public void onFailure(String messageId, OperationResult result) {
                Logger.e(TAG, "Failed to update read state: " + result.getMessage() + " (" + result.getStatusCode() + ")", result.getError());
            }
        });
        return res;
    }

    /**
     * Sets the message state as unread.
     * @param context The application's context
     * @param message The message to set as unread
     * @return 1 for successful setting, 0 for no setting
     */
    public static int setMessageUnread(Context context, RichContent message) {
        return setMessageUnreadById(context, message.getMessageId());
    }

    /**
     * Sets the message state as unread.
     * @param context The application's context
     * @param messageId The id of the message to set as unread
     * @return 1 for successful setting, 0 for no setting
     */
    public static int setMessageUnreadById(Context context, String messageId) {
        int res = RichContentDatabaseHelper.getRichContentDatabaseHelper(context).setMessageUnreadById(messageId);
        updateReadState(context, messageId, false, new OperationCallback<String>() {
            @Override
            public void onSuccess(String messageId, OperationResult result) {

            }

            @Override
            public void onFailure(String messageId, OperationResult result) {
                Logger.e(TAG, "Failed to update unread state: " + result.getMessage() + " (" + result.getStatusCode() + ")", result.getError());
            }
        });
        return res;
    }

    /**
     * Delete a message by id
     * @param context The application's context
     * @param messageId The inbox message id
     * @return 1 for successful deletion, 0 for no deletion
     */
    public static long deleteMessageById(Context context, String messageId) {
        long res = RichContentDatabaseHelper.getRichContentDatabaseHelper(context).deleteMessageById(messageId);
        updateDeleteState(context, messageId, new OperationCallback<String>() {
            @Override
            public void onSuccess(String messageId, OperationResult result) {

            }

            @Override
            public void onFailure(String messageId, OperationResult result) {
                Logger.e(TAG, "Failed to update delete state: " + result.getMessage() + " (" + result.getStatusCode() + ")", result.getError());
            }
        });
        return res;
    }

    /**
     * Deletes a message
     * @param context The application's context
     * @param message The message to delete
     * @return 1 for successful deletion, 0 for no deletion
     */
    public static long deleteMessage(Context context, RichContent message) {
        return deleteMessageById(context, message.getMessageId());
    }

    private static void updateReadState(final Context context, String messageId, boolean state, final OperationCallback<String> callback) {
        try {
            sendUpdates(context, createUpdatePayload(messageId, state, null), callback);
        } catch (JSONException jsone) {
            callback.onFailure(messageId, new OperationResult(false, -1, jsone.getMessage(), jsone));
        }
    }

    private static void updateDeleteState(final Context context, String messageId, final OperationCallback<String> callback) {
        try {
            sendUpdates(context, createUpdatePayload(messageId, null, true), callback);
        } catch (JSONException jsone) {
            callback.onFailure(messageId, new OperationResult(false, -1, jsone.getMessage(), jsone));
        }
    }

    private static String createUpdatePayload(String messageId, Boolean isRead, Boolean isDeleted) throws JSONException{
        JSONObject update = new JSONObject();
        update.put("inboxMessageId", messageId);
        update.put("timestamp", Iso8601.toString(new Date()));
        if(isRead != null) {
            update.put("isRead", isRead);
        }
        if(isDeleted != null) {
            update.put("isDeleted", isDeleted);
        }
        JSONArray updates = new JSONArray();
        updates.put(update);
        JSONObject payload = new JSONObject();
        payload.put("updates", updates);
        return payload.toString();
    }

    private static void sendUpdates(final Context context, final String updatePayload, final OperationCallback<String> callback) {
        EXECUTOR.execute(new Runnable() {
            @Override
            public void run() {
                HttpHelper.Response response = null;
                try {

                    String inboxUpdateUrl = new InboxSyncUrl().getInboxUpdatesUrl(Endpoint.getInstance().getBaseUrl(), context);
                    response = HttpHelper.postJson(inboxUpdateUrl, updatePayload);
                    if (response.getHttpResponseCode() == 202) {
                        Logger.d(TAG, "Successfully updated inbox: " + response.getResponseMessage());
                        if (callback != null) {
                            callback.onSuccess(null, new OperationResult(false, response.getHttpResponseCode(), response.getHttpResponseMessage(), null));
                        }
                    } else {
                        Logger.e(TAG, "Failed updating inbox: " + response.getHttpResponseCode() + " " + response.getHttpResponseMessage());
                        if (callback != null) {
                            callback.onFailure(null, new OperationResult(false, response.getHttpResponseCode(), response.getHttpResponseMessage(), null));
                        }
                    }
                } catch (Exception e) {
                    if (callback != null) {
                        callback.onFailure(null, new OperationResult(false, 0, e.getMessage(), e));
                    }
                    Logger.e(TAG, "Failed to read messages", e);
                }
            }
        });
    }

    /**
     * Synchronizes the inbox with the server
     * @param context The application's context
     * @param callback A callback when the operation is done
     */
    public static void loadInboxMessages(final Context context, final OperationCallback<List<RichContent>> callback) {
        RegistrationDetails registrationDetails = MceSdk.getRegistrationClient().getRegistrationDetails(context);
        if(registrationDetails.getUserId() == null || registrationDetails.getChannelId() == null)
        {
            Logger.i(TAG, "Can not yet sync inbox, SDK is not yet registered with server.");
            return;
        }

        EXECUTOR.execute(new Runnable() {
            @Override
            public void run() {
                HttpHelper.Response response = null;
                try {
                    String lastSync = InboxPreferences.getLastSync(context);
                    if (lastSync == null) {
                        lastSync = Iso8601.toString(new Date(0));
                    }
                    JSONObject lastSyncJSON = new JSONObject();
                    lastSyncJSON.put("lastSynced", lastSync);
                    String inboxSyncUrl = new InboxSyncUrl().getInboxSyncUrl(Endpoint.getInstance().getBaseUrl(), context);
                    response = HttpHelper.postJson(inboxSyncUrl, lastSyncJSON.toString());
                    if (response.getHttpResponseCode() == 200) {
                        Logger.d(TAG, "Successfully loaded messages: " + response.getResponseMessage());
                        JSONObject messagesJSON = new JSONObject(response.getResponseMessage());
                        loadMessages(messagesJSON, context, callback);
                    } else {
                        Logger.e(TAG, "Failed loading messages: " + response.getHttpResponseCode() + " " + response.getHttpResponseMessage());
                        if (callback != null) {
                            callback.onFailure(null, new OperationResult(false, response.getHttpResponseCode(), response.getHttpResponseMessage(), null));
                        }
                    }
                } catch (Exception e) {
                    if (callback != null) {
                        callback.onFailure(null, new OperationResult(false, 0, e.getMessage(), e));
                    }
                    Logger.e(TAG, "Failed to read messages", e);
                }
            }
        });

    }

    private static void loadMessages(JSONObject messagesJSON, Context context, OperationCallback<List<RichContent>> callback) throws JSONException {
        RichContentDatabaseHelper.getRichContentDatabaseHelper(context).clearDeletedMessages();
        JSONArray messages = messagesJSON.getJSONArray("messages");
        List<RichContent> newMessages = new LinkedList<RichContent>();
        boolean updated = false;
        for(int i = 0; i< messages.length(); ++i) {
            try {
                JSONObject messageJSON = messages.getJSONObject(i);
                String messageId = messageJSON.getString("inboxMessageId");
                boolean isDeleted = messageJSON.getBoolean("isDeleted");
                boolean isRead = messageJSON.getBoolean("isRead");
                RichContent rc = getInboxMessageByMessageId(context, messageId);
                if(rc != null) {
                    if(isDeleted && !rc.getIsDeleted()) {
                        RichContentDatabaseHelper.getRichContentDatabaseHelper(context).deleteMessage(rc);
                    }
                    if(isRead && !rc.getIsRead()) {
                        RichContentDatabaseHelper.getRichContentDatabaseHelper(context).setMessageRead(rc);
                    }
                    if(!isRead && rc.getIsRead()) {
                        RichContentDatabaseHelper.getRichContentDatabaseHelper(context).setMessageUnread(rc);
                    }
                    updated = true;
                } else if(!isDeleted){
                    rc = new RichContent();
                    rc.setMessageId(messageId);
                    rc.setContentId(messageJSON.getString("richContentId"));
                    rc.setAttribution(messageJSON.getString("attribution"));
                    rc.setTemplate(messageJSON.getString("template"));
                    rc.setSendDate(Iso8601.toDate(messageJSON.getString("sendDate")));
                    rc.setExpirationDate(Iso8601.toDate(messageJSON.getString("expirationDate")));
                    rc.setIsRead(isRead);
                    rc.setIsDeleted(isDeleted);
                    rc.setContent(messageJSON.getJSONObject("content"));
                    if(RichContentDatabaseHelper.getRichContentDatabaseHelper(context).insertMessage(rc)) {
                        newMessages.add(rc);
                        updated = true;
                    }
                }

            } catch(Exception e) {
                Logger.e(TAG, "Failed to add message", e);
            }
        }
        if(updated) {
            if(!newMessages.isEmpty()) {
                for (RichContent message : newMessages) {
                    synchronized (MESSAGE_ID_TO_BUNDLE) {
                        Bundle bundle = MESSAGE_ID_TO_BUNDLE.remove(message.getContentId());
                        if (bundle != null) {
                            NotificationsUtility.showNotification(context, bundle);
                        }
                    }
                }
            }
            Date lastReceivedDate = new Date();
            Date lastSyncDate = new Date(lastReceivedDate.getTime());
            InboxPreferences.setLastSync(context, Iso8601.toString(lastSyncDate));
            Intent intent = new Intent();
            intent.setPackage(context.getPackageName());
            intent.setAction(INBOX_UPDATE_ACTION);
            context.sendBroadcast(intent);
        }
        if(callback != null) {
            callback.onSuccess(newMessages, new OperationResult(true, 0, null, null));
        }
    }

    /**
     * Retrieves a message by inbox message id
     * @param context The application's context
     * @param messageId The inbox message id
     * @return The message or null if no message with that inbox message id is found
     */
    public static RichContent getInboxMessageByMessageId(Context context, String messageId) {
        RichContentDatabaseHelper.MessageCursor cursor = RichContentDatabaseHelper.getRichContentDatabaseHelper(context).getMessages();
        while (cursor.moveToNext()) {
            RichContent rc = cursor.getRichContent();
            if(rc.getMessageId().equals(messageId)) {
                return rc;
            }
        }
        return null;
    }

    /**
     * Retrieves a message by rich content id
     * @param context The application's context
     * @param contentId The rich content id
     * @return the latest message with the rich content id or null if no message with that rich content id is found
     */
    public static RichContent getInboxMessageByContentId(Context context, String contentId) {
        RichContentDatabaseHelper.MessageCursor cursor = RichContentDatabaseHelper.getRichContentDatabaseHelper(context).getMessages();
        Date lastDate = new Date(0);
        RichContent lastMessage = null;
        while (cursor.moveToNext()) {
            RichContent rc = cursor.getRichContent();
            if(rc.getContentId().equals(contentId) && rc.getSendDate().after(lastDate)) {
                lastMessage = rc;
                lastDate = rc.getSendDate();
            }
        }
        return lastMessage;
    }

    /**
     * Synchronizes the inbox with the server and show the inbox once it's done
     * @param context The application's context
     */
    public static void showInbox(final Context context) {
        loadInboxMessages(context, new OperationCallback<List<RichContent>>() {
            @Override
            public void onSuccess(List<RichContent> richContents, OperationResult result) {
                Intent intent = new Intent(context, RichInboxActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }

            @Override
            public void onFailure(List<RichContent> richContents, OperationResult result) {
                Intent intent = new Intent(context, RichInboxActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });

    }
}
