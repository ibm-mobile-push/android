/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.CursorWrapper;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.ibm.mce.sdk.util.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RichContentDatabaseHelper extends SQLiteOpenHelper {
    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    private static final String TAG="RichContentDatabaseHelper";

    private static final String DB_NAME = "messages.sqlite";
    private static final int VERSION = 1;
    private static final String TABLE_NAME = "notifications";

    private static final String COLUMN_MESSAGE_ID = "messageId";
    private static final String COLUMN_CONTENT_ID = "contentId";
    private static final String COLUMN_TEMPLATE = "template";
    private static final String COLUMN_CONTENT = "content";
    private static final String COLUMN_ATTRIBUTION = "attribution";
    private static final String COLUMN_SEND_DATE = "sendDate";
    private static final String COLUMN_EXPIRATION_DATE = "expirationDate";
    private static final String COLUMN_IS_DELETED = "isDeleted";
    private static final String COLUMN_IS_READ = "isRead";


    private static RichContentDatabaseHelper richContentDatabaseHelper;
    public static RichContentDatabaseHelper getRichContentDatabaseHelper(Context context) {
        if (richContentDatabaseHelper == null)
            richContentDatabaseHelper = new RichContentDatabaseHelper(context);
        return richContentDatabaseHelper;
    }

    public RichContentDatabaseHelper(Context context)
    {
        super(context, DB_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        // create notifications table
        String createTableSql = "CREATE TABLE IF NOT EXISTS \"notifications\"("+"" +
                "\"_id\" Numeric PRIMARY KEY, " +
                "\""+COLUMN_CONTENT+"\" Text, "+
                "\""+COLUMN_CONTENT_ID+"\" Text, "+
                "\""+COLUMN_MESSAGE_ID+"\" Text, "+
                "\""+COLUMN_TEMPLATE+"\" Text, "+
                "\""+COLUMN_ATTRIBUTION+"\" Text, "+
                "\""+COLUMN_EXPIRATION_DATE+"\" INTEGER, "+
                "\""+COLUMN_IS_DELETED+"\" Text, "+
                "\""+COLUMN_IS_READ+"\" Text, "+
                "\""+COLUMN_SEND_DATE+"\" INTEGER );";
        Logger.d(TAG, createTableSql);
        db.execSQL(createTableSql);

        String contentIndexTableSql = "CREATE INDEX \"contentIdIndex\" ON \"notifications\"( \"contentId\" );";
        Logger.d(TAG, contentIndexTableSql);
        db.execSQL(contentIndexTableSql);

        String messageIndexTableSql = "CREATE UNIQUE INDEX \"messageIdIndex\" ON \"notifications\"( \"messageId\" );";
        Logger.d(TAG, messageIndexTableSql);
        db.execSQL(messageIndexTableSql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        // Implement schema upgrades and data massaging when needed
    }

    public long deleteMessage(RichContent message) {
        return deleteMessageById(message.getMessageId());
    }

    public long deleteMessageById(String messageId) {
        String[] whereArgs =  { messageId };
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IS_DELETED, true);
        return getWritableDatabase().update(TABLE_NAME, cv, COLUMN_MESSAGE_ID + "=?", whereArgs);
    }

    public boolean insertMessage(RichContent message)
    {
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_MESSAGE_ID, message.getMessageId());
        cv.put(COLUMN_CONTENT_ID, message.getContentId());
        cv.put(COLUMN_TEMPLATE, message.getTemplate());
        cv.put(COLUMN_CONTENT, message.getContent().toString());
        cv.put(COLUMN_ATTRIBUTION, message.getAttribution());
        cv.put(COLUMN_SEND_DATE, message.getSendDate().getTime());
        cv.put(COLUMN_EXPIRATION_DATE, message.getExpirationDate().getTime());
        cv.put(COLUMN_IS_DELETED, message.getIsDeleted());
        cv.put(COLUMN_IS_READ, message.getIsRead());
        return (getWritableDatabase().insert(TABLE_NAME, null, cv) != -1);
    }

    public MessageCursor getMessages()
    {
        return getMessages(COLUMN_IS_DELETED, "0");
    }

    public MessageCursor getMessagesByContentId(String contentId)
    {
        return getMessages(COLUMN_CONTENT_ID, contentId);
    }

    public MessageCursor getMessagesByMessageId(String messageId)
    {
        return getMessages(COLUMN_MESSAGE_ID, messageId);
    }

    public MessageCursor getMessages(String field, String value)
    {
        String[] args = {value};
        Cursor wrapped = getReadableDatabase().query(TABLE_NAME, null, field + "=?", args, null, null,
                COLUMN_SEND_DATE + " asc");
        return new MessageCursor(wrapped);
    }

    public int setMessageRead(RichContent message) {
        return setMessageReadById(message.getMessageId());
    }

    public int setMessageReadById(String messageId) {
        String[] args = {messageId};
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IS_READ, true);
        return getWritableDatabase().update(TABLE_NAME, cv, COLUMN_MESSAGE_ID + "=?", args);
    }

    public int setMessageUnread(RichContent message) {
        return setMessageUnreadById(message.getMessageId());
    }

    public int setMessageUnreadById(String messageId) {
        String[] args = {messageId};
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IS_READ, false);
        return getWritableDatabase().update(TABLE_NAME, cv, COLUMN_MESSAGE_ID + "=?", args);
    }

    public void clearDeletedMessages() {
        String[] whereArgs =  { "0" };
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IS_DELETED, true);
        int deleted = getWritableDatabase().delete(TABLE_NAME, COLUMN_IS_DELETED + "!=?", whereArgs);


    }



    public class MessageCursor extends CursorWrapper {

        private List<String> types = new ArrayList<String>();

        public MessageCursor(Cursor cursor) {
            super(cursor);
        }

        public RichContent getRichContent()
        {

            RichContent message =  new RichContent();

            String messageId = getString(getColumnIndex(COLUMN_MESSAGE_ID));
            message.setMessageId(messageId);

            String contentId = getString(getColumnIndex(COLUMN_CONTENT_ID));
            message.setContentId(contentId);

            String template = getString(getColumnIndex(COLUMN_TEMPLATE));
            message.setTemplate(template);

            String attribution = getString(getColumnIndex(COLUMN_ATTRIBUTION));
            message.setAttribution(attribution);

            String contentString = getString(getColumnIndex(COLUMN_CONTENT));
            JSONObject content;
            try {
                content = new JSONObject(contentString);
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
            message.setContent(content);

            Long sendDateLong = getLong(getColumnIndex(COLUMN_SEND_DATE));
            Date sendDate = new Date(sendDateLong);
            message.setSendDate(sendDate);


            Long expirationDateLong = getLong(getColumnIndex(COLUMN_EXPIRATION_DATE));
            Date expirationDate = new Date(expirationDateLong);
            message.setExpirationDate(expirationDate);

            Boolean isDeleted = getInt(getColumnIndex(COLUMN_IS_DELETED))>0;
            message.setIsDeleted(isDeleted);

            Boolean isRead = getInt(getColumnIndex(COLUMN_IS_READ))>0;
            message.setIsRead(isRead);

            return message;
        }
    }


}

