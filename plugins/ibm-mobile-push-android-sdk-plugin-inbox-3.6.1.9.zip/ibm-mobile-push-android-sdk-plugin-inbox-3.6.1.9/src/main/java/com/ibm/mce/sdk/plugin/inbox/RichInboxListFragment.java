/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import android.annotation.TargetApi;
import android.app.FragmentManager;
import android.app.ListFragment;
import android.app.LoaderManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.Loader;
import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CursorAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.ibm.mce.sdk.api.OperationCallback;
import com.ibm.mce.sdk.api.OperationResult;
import com.ibm.mce.sdk.util.Logger;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class RichInboxListFragment extends ListFragment implements LoaderManager.LoaderCallbacks<Cursor> {
    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n? Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";
    private static final String TAG = "RichInboxListFragment";

    private BroadcastReceiver inboxUpdaterReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            RichInboxListFragment.this.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    getLoaderManager().restartLoader(0, null, RichInboxListFragment.this);
                }
            });
        }
    };

    public Integer getCount()
    {
        MessageCursorAdapter cursorAdapter = (MessageCursorAdapter)getListAdapter();
        if(cursorAdapter==null)
            return null;

        return cursorAdapter.getCount();
    }

    // User clicked on message
    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {

        super.onListItemClick(l, v, position, id);
        showMessage(position, true);

        Configuration config = getActivity().getResources().getConfiguration();
        if(!config.isLayoutSizeAtLeast(Configuration.SCREENLAYOUT_SIZE_LARGE)) {
            // Phone interface
            getActivity().invalidateOptionsMenu();
        }
    }



    private void showMessage(String contentId) {
        Date lastDate= new Date(0);
        int lastMessageIndex = -1;
        for(int i = 0; i < getCount() ; ++i) {
            RichContent message = getMessage(i);
            if(message.getContentId().equals(contentId) && message.getSendDate().after(lastDate)) {
                lastMessageIndex = i;
                lastDate=message.getSendDate();
            }
        }
        if(lastMessageIndex != -1) {
            showMessage(lastMessageIndex, false);
        }
    }

    private void showMessage(int position, boolean fromList) {

        if(getMessage(position).getIsExpired())
        {
            Toast.makeText(getActivity(), "Message has been expired", Toast.LENGTH_SHORT).show();
            return;
        }
        List<RichContent> messages = new ArrayList<RichContent>(getCount());
        for(int i = 0; i < getCount() ; ++i) {
            messages.add(getMessage(i));
        }
        try {
            Intent intent = new Intent(getView().getContext().getApplicationContext(), InboxMessageDisplayActivity.class);
            intent.putExtra("messages", InboxMessageDisplayActivity.getInboxMessageAsJSONArray(messages).toString());
            intent.putExtra("index", position);
            intent.putExtra("activityId", ((RichInboxActivity)getActivity()).getId());
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getView().getContext().getApplicationContext().startActivity(intent);
            if(fromList) {
                InboxEvents.sendInboxMessageOpenedEvent(getView().getContext().getApplicationContext(), getMessage(position));
            }

        } catch(JSONException e) {
            Logger.e(TAG, "Failed to open message", e);
        }
    }

    @TargetApi(17)
    private RichInboxFragment getRichInboxFragment() {
        RichInboxFragment richInboxFragment = (RichInboxFragment) (getParentFragment().getFragmentManager().findFragmentById(getResources().getIdentifier("rich_inbox_fragment", "id", getView().getContext().getPackageName())));
        return richInboxFragment;
    }

    private RichInboxFragment getRichInboxFragmentOldApi() {
        RichInboxFragment richInboxFragment = (RichInboxFragment) (getFragmentManager().findFragmentById(getResources().getIdentifier("rich_inbox_fragment", "id", getView().getContext().getPackageName())));
        return richInboxFragment;
    }

    public RichContent getMessage(int index)
    {
        ListAdapter adapter = getListAdapter();
        int count = adapter.getCount();

        // Bounds check
        if(index > count-1)
            return null;

        if(index < 0)
            return null;

        RichContentDatabaseHelper.MessageCursor messageCursor = (RichContentDatabaseHelper.MessageCursor) adapter.getItem(index);
        return messageCursor.getRichContent();
    }

    public void restartLoader()
    {
        getLoaderManager().restartLoader(0, null, this);
    }

    public void notifyDataSetChanged()
    {
        MessageCursorAdapter cursorAdapter = (MessageCursorAdapter)getListAdapter();
        cursorAdapter.notifyDataSetChanged();
    }

    @Override
    public void onResume() {
        super.onResume();
        InboxMessagesClient.loadInboxMessages(getActivity().getApplicationContext(), new OperationCallback<List<RichContent>>() {
            @Override
            public void onSuccess(List<RichContent> richContents, OperationResult result) {
                RichInboxListFragment.this.getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        getLoaderManager().restartLoader(0, null, RichInboxListFragment.this);
                    }
                });
                getActivity().registerReceiver(inboxUpdaterReceiver, new IntentFilter(InboxMessagesClient.INBOX_UPDATE_ACTION));
                getListView().setOnScrollListener(new AbsListView.OnScrollListener() {

                    private int firstVisiblePosition = -1;
                    private int lastVisiblePosition = -1;

                    @Override
                    public void onScrollStateChanged(AbsListView view, int scrollState) {

                    }

                    @Override
                    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                        int newFirstVisiblePosition = view.getFirstVisiblePosition();
                        int newLastVisiblePosition = view.getLastVisiblePosition();
                        if (firstVisiblePosition != -1 && lastVisiblePosition != -1) {
                            for (int i = firstVisiblePosition; i < newFirstVisiblePosition; ++i) {
                                RichContent message = getMessage(i);
                                RichContentTemplateRegistry.getRegisteredTemplate(message.getTemplate()).getPreviewFragment().viewHidden(message, ((RichInboxActivity) getActivity()).getId());
                            }
                            for (int i = lastVisiblePosition; i > newLastVisiblePosition; --i) {
                                RichContent message = getMessage(i);
                                RichContentTemplateRegistry.getRegisteredTemplate(message.getTemplate()).getPreviewFragment().viewHidden(message, ((RichInboxActivity) getActivity()).getId());

                            }
                        }
                        firstVisiblePosition = newFirstVisiblePosition;
                        lastVisiblePosition = newLastVisiblePosition;

                    }
                });
            }

            @Override
            public void onFailure(List<RichContent> richContents, OperationResult result) {

            }
        });

    }

    private void viewHidden() {
        for(int i=0; i<getCount();++i) {
            RichContent message = getMessage(i);
            RichContentTemplateRegistry.getRegisteredTemplate(message.getTemplate()).getPreviewFragment().viewHidden(message, ((RichInboxActivity) getActivity()).getId());
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        viewHidden();
    }

    @Override
    public void onPause() {
        super.onPause();
        try {
            getActivity().unregisterReceiver(inboxUpdaterReceiver);
        } catch (Throwable t) {

        }
    }

    @Override
    public void onStart()
    {
        getLoaderManager().restartLoader(0, null, this);
        getListView().setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        getListView().setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public void onItemCheckedStateChanged(ActionMode actionMode, int i, long l, boolean b) {
                // required but not needed in implementation
            }

            @Override
            public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
                MenuInflater inflater = actionMode.getMenuInflater();
                inflater.inflate(getResources().getIdentifier("rich_inbox_context", "menu", getView().getContext().getPackageName()), menu);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
                // required but not needed in implementation
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
               int id = menuItem.getItemId();
                if(getResources().getIdentifier("delete_message", "id", getView().getContext().getPackageName()) == id) {
                    MessageCursorAdapter cursorAdapter = (MessageCursorAdapter) getListAdapter();

                    for (int i = cursorAdapter.getCount() - 1; i >= 0; i--) {
                        if (getListView().isItemChecked(i)) {
                            RichContent message = getMessage(i);
                           InboxMessagesClient.deleteMessage(getView().getContext(), message);
                        }
                    }
                    actionMode.finish();
                    getLoaderManager().restartLoader(0, null, RichInboxListFragment.this);
                    return true;
                } else {
                    return false;
                }

            }

            @Override
            public void onDestroyActionMode(ActionMode actionMode) {
                // required but not needed in implementation
            }
        });
        super.onStart();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        getLoaderManager().restartLoader(0, null, null);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState)
    {
        getLoaderManager().initLoader(0, null, this);
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args)
    {
        return new RichInboxCursorLoader(getActivity());
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor)
    {
        FragmentManager fragmentManager = getFragmentManager();

        RichInboxFragment richInboxFragment = null;
        if(fragmentManager != null) {
            richInboxFragment = (RichInboxFragment) fragmentManager.findFragmentById(getResources().getIdentifier("rich_inbox_fragment", "id", getView().getContext().getPackageName()));
        }
        if(richInboxFragment == null) {
            richInboxFragment = Build.VERSION.SDK_INT >= 17 ? this.getRichInboxFragment() : this.getRichInboxFragmentOldApi();
        }
        MessageCursorAdapter adapter = new MessageCursorAdapter(getActivity(),
                (RichContentDatabaseHelper.MessageCursor)cursor, richInboxFragment);
        setListAdapter(adapter);
        setEmptyText("No messages");

// tablet interface
        Configuration config = getActivity().getResources().getConfiguration();
        if(config.isLayoutSizeAtLeast(Configuration.SCREENLAYOUT_SIZE_LARGE)) {
            richInboxFragment.showContent(fragmentManager);
        }
        Intent intent = getActivity().getIntent();
        if(intent != null) {
            String contentId = intent.getStringExtra("contentId");
            if(contentId != null) {
                intent.putExtra("contentId", (String)null);
                showMessage(contentId);
            }
        }
    }


    @Override
    public void onLoaderReset(Loader<Cursor> loader)
    {
        setListAdapter(null);
    }

    public static class MessageCursorAdapter extends CursorAdapter
    {
        private RichContentDatabaseHelper.MessageCursor messageCursor;
        private Context context;
        private boolean isTablet;
        RichInboxFragment richInboxFragment;
        private InboxMessagePreviewFragment previewFragment;
        private long activityId;

        public RichContentDatabaseHelper.MessageCursor getMessageCursor() {
            return messageCursor;
        }

        public boolean isTablet() {
            return isTablet;
        }

        public Context getContext() {
            return context;
        }

        public RichInboxFragment getRichInboxFragment() {
            return richInboxFragment;
        }

        public long getActivityId() {
            return activityId;
        }

        public MessageCursorAdapter(Context context, RichContentDatabaseHelper.MessageCursor cursor,
                                    RichInboxFragment richInboxFragment) {
            super(context, cursor, 0);
            this.richInboxFragment = richInboxFragment;
            this.context = context;
            messageCursor = cursor;

            Configuration config = this.context.getResources().getConfiguration();
            isTablet = config.isLayoutSizeAtLeast(Configuration.SCREENLAYOUT_SIZE_LARGE);
            activityId = ((RichInboxActivity)context).getId();
        }

        @Override
        public int getViewTypeCount() {
            return Math.max(1,messageCursor.getCount());
        }

        @Override
        public int getItemViewType(int position) {
            return position;
        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            previewFragment = RichContentTemplateRegistry.getRegisteredTemplate(getMessageCursor().getRichContent().getTemplate()).getPreviewFragment();
            return previewFragment.newView(this, context, cursor, parent);
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor)
        {
            previewFragment = RichContentTemplateRegistry.getRegisteredTemplate(getMessageCursor().getRichContent().getTemplate()).getPreviewFragment();
            previewFragment.bindView(this, view, context, cursor);
        }
    }
}
