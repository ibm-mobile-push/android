/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.os.SystemClock;

import com.ibm.mce.sdk.api.OperationCallback;
import com.ibm.mce.sdk.api.OperationResult;
import com.ibm.mce.sdk.util.Logger;
import com.ibm.mce.sdk.wi.WakefulAlarmListener;

import java.util.List;
import java.util.Map;

public class InboxUpdateService extends WakefulAlarmListener {
    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";
    private static final String TAG =  "InboxUpdateService";

    private final long schedulingInterval;

    public InboxUpdateService() {
        super(InboxUpdateService.class.getName());
        schedulingInterval = 20*60*1000;
    }

    @Override
    public void onWakefulTrigger(Context context, Map<String, String> extra) {
        synchronized (context) {
            InboxMessagesClient.loadInboxMessages(context, new OperationCallback<List<RichContent>>() {
                @Override
                public void onSuccess(List<RichContent> newMessages, OperationResult result) {
                    Logger.d(TAG, "Inbox update service got "+newMessages.size()+" new messages");
                }

                @Override
                public void onFailure(List<RichContent> richContents, OperationResult result) {
                    Logger.e(TAG,"Inbox update service failed", result.getError());
                }
            });
        }
    }

    @Override
    public void scheduleAlarms(Context context, AlarmManager mgr, PendingIntent pi, boolean sceduleNow) {
        mgr.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime(),
                schedulingInterval, pi);
        Logger.d(TAG, "Inbox update service was scheduled with interval " + schedulingInterval);
    }

    @Override
    public long getMaxAge(Context context) {
        return schedulingInterval;
    }
}
