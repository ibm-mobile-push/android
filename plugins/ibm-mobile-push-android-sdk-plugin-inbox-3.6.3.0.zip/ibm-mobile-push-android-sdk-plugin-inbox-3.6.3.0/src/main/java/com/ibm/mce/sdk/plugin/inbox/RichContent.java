/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import com.ibm.mce.sdk.api.notification.Action;
import com.ibm.mce.sdk.notification.ActionImpl;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class RichContent {
    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n� Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    private String contentId;
    private String messageId;
    private String template;
    private JSONObject content;
    private String attribution;
    private Date sendDate;
    private Date expirationDate;
    private Boolean isDeleted;
    private Boolean isRead;

    public String getContentId() {
        return contentId;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setContentId(String contentId) {
        this.contentId = contentId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getTemplate() {
        return template;
    }

    public JSONObject getContent() {
        return content;
    }

    public void setContent(JSONObject content) {
        this.content = content;
    }

    public Date getSendDate() {
        return sendDate;
    }

    public void setSendDate(Date sendDate) {
        this.sendDate = sendDate;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public JSONObject getIdToAction() throws JSONException {
        JSONObject messageDetailsJSON = content.optJSONObject("messageDetails");
        if(messageDetailsJSON != null) {
            Object actionsObj = messageDetailsJSON.opt("actions");
            if(actionsObj == null) {
                actionsObj = content.opt("actions");
            }
            if(actionsObj != null) {
                if(actionsObj instanceof JSONArray) {
                    JSONArray actionsArray = messageDetailsJSON.optJSONArray("actions");
                    JSONObject idToAction = new JSONObject();
                    for(int i=0;i<actionsArray.length();++i) {
                        String id =  actionsArray.getJSONObject(i).optString("id");
                        if(id != null) {
                            idToAction.put(id, actionsArray.getJSONObject(i));
                        }
                    }
                    return idToAction;
                } else if(actionsObj instanceof JSONObject) {
                    return (JSONObject)actionsObj;
                } else {
                    return new JSONObject();
                }
            }
        }
        return new JSONObject();
    }

    public String getAttribution() {
        return attribution;
    }

    public void setAttribution(String attribution) {
        this.attribution = attribution;
    }

    public String getSubject() {
        JSONObject messagePreviewJSON = content.optJSONObject("messagePreview");
        if(messagePreviewJSON != null) {
            return messagePreviewJSON.optString("subject", "no subject");
        } else {
            return "no subject";
        }
    }

    public String getPreview() {
        JSONObject messagePreviewJSON = content.optJSONObject("messagePreview");
        if(messagePreviewJSON != null) {
            return messagePreviewJSON.optString("previewContent", "no preview");
        } else {
            return "no preview";
        }
    }

    public String getRichContent() {
        JSONObject messagePreviewJSON = content.optJSONObject("messageDetails");
        if(messagePreviewJSON != null) {
            return messagePreviewJSON.optString("richContent", "no rich content");
        } else {
            return "no rich content";
        }
    }





    public boolean getIsExpired() {
        return expirationDate.before( new Date() );
    }

    public Action getAction(String id) {
        try {
            JSONObject actionJSON = getIdToAction().optJSONObject(id);
            if(actionJSON != null) {
                String type = actionJSON.getString("type");
                String name = actionJSON.optString("name", "");
                String value = actionJSON.get("value").toString();
                Map<String, String> payload = new HashMap<String, String>();
                payload.put("value", value);
                Iterator<String> keys = actionJSON.keys();
                while(keys.hasNext()) {
                    String key = keys.next();
                    if(!"type".equals(key) && !"name".equals(key) && !"value".equals(key)) {
                        payload.put(key, actionJSON.get(key).toString());
                    }
                }
                Action action = new ActionImpl(type, name, payload);
                return action;
            } else {
                return null;
            }
        } catch(JSONException e) {
            return null;
        }
    }

    public static JSONObject toJSON(RichContent content) throws JSONException {
        JSONObject contentJSON = new JSONObject();
        contentJSON.put("contentId", content.getContentId());
        contentJSON.put("messageId", content.getMessageId());
        contentJSON.put("attribution", content.getAttribution());
        contentJSON.put("template", content.getTemplate());
        contentJSON.put("content", content.getContent());
        contentJSON.put("expirationDate", content.getExpirationDate().getTime());
        contentJSON.put("sendDate", content.getSendDate().getTime());
        contentJSON.put("isRead", content.isRead);
        contentJSON.put("isDeleted", content.isDeleted);
        return contentJSON;
    }

    public static RichContent fromJSON(JSONObject contentJSON) throws JSONException {
        RichContent content = new RichContent();
        content.setContentId(contentJSON.getString("contentId"));
        content.setMessageId(contentJSON.getString("messageId"));
        content.setAttribution(contentJSON.getString("attribution"));
        content.setTemplate(contentJSON.getString("template"));
        content.setContent(contentJSON.getJSONObject("content"));
        content.setExpirationDate(new Date(contentJSON.getLong("expirationDate")));
        content.setSendDate(new Date(contentJSON.getLong("sendDate")));
        content.setIsRead(contentJSON.getBoolean("isRead"));
        content.setIsDeleted(contentJSON.getBoolean("isDeleted"));
        return content;
    }
}
