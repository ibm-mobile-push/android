/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import android.content.Intent;
import android.net.Uri;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.ibm.mce.sdk.api.notification.Action;
import com.ibm.mce.sdk.api.notification.MceNotificationAction;
import com.ibm.mce.sdk.api.notification.MceNotificationActionRegistry;
import com.ibm.mce.sdk.notification.ActionImpl;

import java.util.HashMap;
import java.util.Map;

public class HtmlInboxMessageDisplay implements InboxMessageDisplay {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    private static final String TAG = "HtmlInboxMessageDisplay";

    @Override
    public void displayMessage(final RichContent message, final InboxMessageDisplayActivity activity) {
        activity.setTheme(android.R.style.Theme_Holo);
        int layoutId = activity.getResources().getIdentifier("inbox_message_activity", "layout", activity.getPackageName());
        activity.setContentView(layoutId);
        int webViewId = activity.getResources().getIdentifier("webView", "id", activity.getPackageName());
        WebView webView = (WebView) activity.findViewById(webViewId);
        WebSettings settings = webView.getSettings();
        settings.setDefaultTextEncodingName("utf-8");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                String scheme = uri.getScheme();
                if (scheme.equalsIgnoreCase("actionid")) {
                    String actionId = uri.getSchemeSpecificPart();
                    Action action = message.getAction(actionId);
                    if (action != null) {
                        MceNotificationAction actionImpl = MceNotificationActionRegistry.getNotificationAction(action.getType());
                        if (actionImpl != null) {
                            Map<String, String> payload = new HashMap<String, String>();
                            for (String key : action.getPayloadKeys()) {
                                payload.put(key, action.getPayloadValue(key));
                            }
                            actionImpl.handleAction(view.getContext().getApplicationContext(), action.getType(), action.getType(), message.getAttribution(), null, payload, false);
                            InboxEvents.sendInboxMessageActionTakenEvent(view.getContext().getApplicationContext(), message, action);
                        }
                    }

                    return true;
                } else {
                    String type = "url";
                    String value = url;
                    if (scheme.equalsIgnoreCase("tel")) {
                        type = "dial";
                        value = uri.getSchemeSpecificPart();
                    }

                    MceNotificationAction actionImpl = MceNotificationActionRegistry.getNotificationAction(type);
                    if (actionImpl != null) {
                        Map<String, String> payload = new HashMap<String, String>();
                        payload.put("value", value);
                        Action action = new ActionImpl(type, type, payload);
                        InboxEvents.sendInboxMessageActionTakenEvent(view.getContext().getApplicationContext(), message, action);
                    }
                }

                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                activity.startActivity(intent);

                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                String title = view.getTitle();
                if (title != null && title.length() > 0 && !title.startsWith("data:text/html") && !title.equals("about:blank")) {
                    activity.setTitle(title);
                } else {
                    activity.setTitle(message.getSubject());
                }
            }
        });
        String richContent = message.getRichContent();
        if(richContent != null) {
            webView.loadDataWithBaseURL(null, richContent, "text/html; charset=utf-8", "UTF-8", null);
        }
    }

    @Override
    public void viewHidden(RichContent message, long activityId) {

    }
}
