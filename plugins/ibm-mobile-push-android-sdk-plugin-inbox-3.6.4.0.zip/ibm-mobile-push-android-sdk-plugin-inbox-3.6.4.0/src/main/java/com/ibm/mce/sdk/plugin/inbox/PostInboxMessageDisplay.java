/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2016.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import android.view.View;

import com.ibm.mce.sdk.util.Logger;

import org.json.JSONException;

public class PostInboxMessageDisplay implements InboxMessageDisplay {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";
    private static final String TAG = "PostInboxMessageDisplay";

    @Override
    public void displayMessage(RichContent message, InboxMessageDisplayActivity activity) {
        try {
            PostMessageTemplate.PostMessage postMessage = new PostMessageTemplate.PostMessage(message);


            String layoutName = "post_full_layout";
            if(postMessage.getContentText() != null && postMessage.getContentImage() != null) {
                layoutName = "post_full_text_image_layout";
            }  else if(postMessage.getContentText() != null && postMessage.getContentVideo() != null) {
                layoutName = "post_full_text_video_layout";
            } else if(postMessage.getContentText() == null && postMessage.getContentImage() != null) {
                layoutName = "post_full_image_layout";
            } else if(postMessage.getContentText() == null && postMessage.getContentVideo() != null) {
                layoutName = "post_full_video_layout";
            } else if(postMessage.getContentText() != null) {
                layoutName = "post_full_text_layout";
            }

            activity.setContentView(activity.getResources().getIdentifier(layoutName, "layout", activity.getPackageName()));
            View view = activity.getWindow().getDecorView();

            PostMessageTemplate.updateHeaderView(activity, activity, view , postMessage);
            PostMessageTemplate.updateContentTextView(activity, view, postMessage);
            PostMessageTemplate.updateContentImageView(activity, activity, view, postMessage);
            PostMessageTemplate.updateContentVideoView(activity, activity.getActivityId(), view , postMessage);
            PostMessageTemplate.updateButtons(activity, view, postMessage, message);
            activity.setTitle(postMessage.getHeader());

        } catch(JSONException e) {
            Logger.e(TAG, "Failed to update message view", e);
        }
    }

    @Override
    public void viewHidden(RichContent message, long activityId) {
        if(message.getTemplate().equals("post")) {
            try {
                PostMessageTemplate.PostMessage postMessage = new PostMessageTemplate.PostMessage(message);
                if(postMessage.getContentVideo() != null) {
                    PostMessageTemplate.setHidden(postMessage.getContentVideo(), activityId);
                }
            } catch (Exception e) {

            }
        }
    }
}
