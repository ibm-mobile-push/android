/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;


import android.content.Context;

import com.ibm.mce.sdk.api.Constants;
import com.ibm.mce.sdk.api.MceSdk;
import com.ibm.mce.sdk.api.OperationCallback;
import com.ibm.mce.sdk.api.OperationResult;
import com.ibm.mce.sdk.api.attribute.Attribute;
import com.ibm.mce.sdk.api.attribute.StringAttribute;
import com.ibm.mce.sdk.api.event.Event;
import com.ibm.mce.sdk.api.notification.Action;
import com.ibm.mce.sdk.events.EventsManager;
import com.ibm.mce.sdk.notification.MceNotificationActionImpl;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

class InboxEvents {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    public static void sendInboxNotificationOpenedEvent(final Context context, Action action, String attribution, String mailingId) {
        List<Attribute> eventAttributes = new LinkedList<Attribute>();
        eventAttributes.add(new StringAttribute("Extension", "inbox"));
        String contentId = action.getPayloadValue("value");
        if(contentId != null) {
            eventAttributes.add(new StringAttribute("richContentId", contentId));
        }
        final Event event = new Event(Constants.Notifications.SIMPLE_NOTIFICATION_EVENT_TYPE, "inboxMessageOpened", new Date(), eventAttributes, attribution, mailingId);
        MceSdk.getEventsClient(false).sendEvent(context, event, new OperationCallback<Event>() {
            @Override
            public void onSuccess(Event event, OperationResult result) {

            }

            @Override
            public void onFailure(Event event, OperationResult result) {
                MceSdk.getQueuedEventsClient().sendEvent(context, event);
            }
        });
    }

    public static void sendInboxMessageOpenedEvent(final Context context,RichContent message) {
        List<Attribute> eventAttributes = new LinkedList<Attribute>();
        eventAttributes.add(new StringAttribute("richContentId", message.getContentId()));
        eventAttributes.add(new StringAttribute("inboxMessageId", message.getMessageId()));

        final Event event = new Event("inbox", "messageOpened", new Date(), eventAttributes, message.getAttribution(), null);
        MceSdk.getEventsClient(false).sendEvent(context, event, new OperationCallback<Event>() {
            @Override
            public void onSuccess(Event event, OperationResult result) {

            }

            @Override
            public void onFailure(Event event, OperationResult result) {
                MceSdk.getQueuedEventsClient().sendEvent(context, event);
            }
        });
    }

    public static void sendInboxMessageActionTakenEvent(final Context context, RichContent message, Action action) {
        String name = action.getType();
        List<Attribute> eventAttributes = new LinkedList<Attribute>();
        MceNotificationActionImpl.ClickEventDetails clickEventDetails = MceNotificationActionImpl.getClickEventDetails(action.getType());
        if(clickEventDetails != null) {
            name = clickEventDetails.eventName;
            String value = action.getPayloadValue("value");
            eventAttributes.add(new StringAttribute(clickEventDetails.valueName, value));
        } else {
            for(String key : action.getPayloadKeys()) {
                eventAttributes.add(new StringAttribute(key, action.getPayloadValue(key)));
            }
        }

        eventAttributes.add(new StringAttribute("richContentId", message.getContentId()));
        eventAttributes.add(new StringAttribute("inboxMessageId", message.getMessageId()));
        final Event event = new Event("inboxMessage", name, new Date(), eventAttributes, message.getAttribution(), null);
        MceSdk.getEventsClient(false).sendEvent(context, event , new OperationCallback<Event>() {
            @Override
            public void onSuccess(Event event, OperationResult result) {

            }

            @Override
            public void onFailure(Event event, OperationResult result) {
                MceSdk.getQueuedEventsClient().sendEvent(context, event);
            }
        });
    }
}
