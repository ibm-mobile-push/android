/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2016.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;


import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Point;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ibm.mce.sdk.util.Logger;

import org.json.JSONException;

/**
 * This class is the preview implementation of the post template
 */
public class PostMessagePreviewFragment implements InboxMessagePreviewFragment {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";
    private static final String TAG = "PostMessagePreviewFragment";


    /**
     * This method generates a new preview view
     * @param adapter The messages adapter
     * @param context The application context
     * @param cursor The messages cursor
     * @param parent The fragment parent
     * @return The new view
     */
    @Override
    public View newView(final RichInboxListFragment.MessageCursorAdapter adapter, final Context context, Cursor cursor, ViewGroup parent) {

        RichContent message = adapter.getMessageCursor().getRichContent();
        try {
            PostMessageTemplate.PostMessage postMessage = new PostMessageTemplate.PostMessage(message);
            String layoutName = "post_inbox_layout";
            if(postMessage.getContentText() != null && postMessage.getContentImage() != null) {
                layoutName = "post_inbox_text_image_layout";
            } else if(postMessage.getContentText() != null && postMessage.getContentVideo() != null) {
                layoutName = "post_inbox_text_video_layout";
            }
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View rowView = inflater.inflate(context.getResources().getIdentifier(layoutName, "layout", context.getPackageName()), parent, false);

            int height = getSizeInDp(40, rowView);

            PostMessageTemplate.updateHeaderView(context, (Activity) adapter.getContext(), rowView, postMessage);

            TextView textView = PostMessageTemplate.updateContentTextView(context, rowView, postMessage);
            if(textView != null) {
                height += getRequiredTextViewHeight(textView, (Activity) adapter.getContext());
            }

            if(PostMessageTemplate.updateContentImageView(context, (Activity) adapter.getContext(), rowView, postMessage)) {
                height += getSizeInDp(100, rowView);
            } else {
                RelativeLayout videoLayout = PostMessageTemplate.updateContentVideoView(context, (Activity) adapter.getContext(), rowView, postMessage);
                if (videoLayout != null) {
                    videoLayout.setMinimumHeight(getSizeInDp(150, rowView));
                    videoLayout.setMinimumWidth(getScreenSize((Activity) adapter.getContext()).x);
                    height += getSizeInDp(150, rowView);
                }
            }



            if(PostMessageTemplate.updateButtons(context, rowView, postMessage, message)) {
                height += getSizeInDp(40, rowView);
            }

            rowView.setMinimumHeight(height);
            rowView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height));

            return rowView;
        } catch(JSONException e) {
            Logger.e(TAG, "Failed to update inbox row view", e);
            return null;
        }

    }


    /**
     * This method display an html message preview in the fragment
     * @param adapter The messages adapter
     * @param view The containg view
     * @param context The application context
     * @param cursor The messages cursor
     */
    @Override
    public void bindView(RichInboxListFragment.MessageCursorAdapter adapter, View view, Context context, Cursor cursor) {


    }

    /**
     * This method is called when the view is hiiden
     * @param message The view message
     * @param activityId The containing activity id
     */
    @Override
    public void viewHidden(RichContent message, long activityId) {
        if(message.getTemplate().equals("post")) {
            try {
                PostMessageTemplate.PostMessage postMessage = new PostMessageTemplate.PostMessage(message);
                if(postMessage.getContentVideo() != null) {
                    PostMessageTemplate.setHidden(postMessage.getContentVideo(), activityId);
                }
            } catch (Exception e) {

            }
        }
    }

    private int getSizeInDp(int size, View view) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, size, view.getContext().getResources().getDisplayMetrics());
    }

    private int getRequiredTextViewHeight(TextView textView, Activity activity) {
        Point p = getScreenSize(activity);
        int widthMeasureSpec = View.MeasureSpec.makeMeasureSpec(p.x, View.MeasureSpec.AT_MOST);
        int heightMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        textView.measure(widthMeasureSpec, heightMeasureSpec);
        return textView.getMeasuredHeight();
    }

    private Point getScreenSize(Activity activity) {
        Point p = new Point();
        activity.getWindowManager().getDefaultDisplay().getSize(p);
        return p;
    }


}
