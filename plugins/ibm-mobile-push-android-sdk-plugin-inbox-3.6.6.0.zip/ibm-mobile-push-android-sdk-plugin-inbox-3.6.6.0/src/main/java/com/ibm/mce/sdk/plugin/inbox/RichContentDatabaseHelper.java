/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.CursorWrapper;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.ibm.mce.sdk.util.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is the inbox messages dao.
 */
public class RichContentDatabaseHelper extends SQLiteOpenHelper {
    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    private static final String TAG="RichContentDatabaseHelper";

    private static final String DB_NAME = "messages.sqlite";
    private static final int VERSION = 1;
    private static final String TABLE_NAME = "notifications";

    private static final String COLUMN_MESSAGE_ID = "mailingId";
    private static final String COLUMN_CONTENT_ID = "contentId";
    private static final String COLUMN_TEMPLATE = "template";
    private static final String COLUMN_CONTENT = "content";
    private static final String COLUMN_ATTRIBUTION = "attribution";
    private static final String COLUMN_SEND_DATE = "sendDate";
    private static final String COLUMN_EXPIRATION_DATE = "expirationDate";
    private static final String COLUMN_IS_DELETED = "isDeleted";
    private static final String COLUMN_IS_READ = "isRead";


    private static RichContentDatabaseHelper richContentDatabaseHelper;

    /**
     * Gets the dao instance
     * @param context The application's context
     * @return The dao instance
     */
    public static RichContentDatabaseHelper getRichContentDatabaseHelper(Context context) {
        if (richContentDatabaseHelper == null)
            richContentDatabaseHelper = new RichContentDatabaseHelper(context);
        return richContentDatabaseHelper;
    }

    RichContentDatabaseHelper(Context context)
    {
        super(context, DB_NAME, null, VERSION);
    }

    /**
     * This method creates the inbox db tables
     * @param db THe inbox db
     */
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        // create notifications table
        String createTableSql = "CREATE TABLE IF NOT EXISTS \"notifications\"("+"" +
                "\"_id\" Numeric PRIMARY KEY, " +
                "\""+COLUMN_CONTENT+"\" Text, "+
                "\""+COLUMN_CONTENT_ID+"\" Text, "+
                "\""+COLUMN_MESSAGE_ID+"\" Text, "+
                "\""+COLUMN_TEMPLATE+"\" Text, "+
                "\""+COLUMN_ATTRIBUTION+"\" Text, "+
                "\""+COLUMN_EXPIRATION_DATE+"\" INTEGER, "+
                "\""+COLUMN_IS_DELETED+"\" Text, "+
                "\""+COLUMN_IS_READ+"\" Text, "+
                "\""+COLUMN_SEND_DATE+"\" INTEGER );";
        Logger.d(TAG, createTableSql);
        db.execSQL(createTableSql);

        String contentIndexTableSql = "CREATE INDEX \"contentIdIndex\" ON \"notifications\"( \"contentId\" );";
        Logger.d(TAG, contentIndexTableSql);
        db.execSQL(contentIndexTableSql);

        String messageIndexTableSql = "CREATE UNIQUE INDEX \"messageIdIndex\" ON \"notifications\"( \"mailingId\" );";
        Logger.d(TAG, messageIndexTableSql);
        db.execSQL(messageIndexTableSql);
    }

    /**
     * This method updrages the inbox db tables
     * @param db The inbox db
     * @param oldVersion The old version
     * @param newVersion The new version
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        // Implement schema upgrades and data massaging when needed
    }

    /**
     * Deletes an inbox message
     * @param message The message
     * @return the number of messages deleted
     */
    public long deleteMessage(RichContent message) {
        return deleteMessageById(message.getMessageId());
    }

    /**
     * Deletes an inbox message
     * @param messageId The message id
     * @return the number of messages deleted
     */
    public long deleteMessageById(String messageId) {
        String[] whereArgs =  { messageId };
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IS_DELETED, true);
        return getWritableDatabase().update(TABLE_NAME, cv, COLUMN_MESSAGE_ID + "=?", whereArgs);
    }

    /**
     * Adds a new inbox message
     * @param message The message
     * @return true if added, false otherwise
     */
    public boolean insertMessage(RichContent message)
    {
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_MESSAGE_ID, message.getMessageId());
        cv.put(COLUMN_CONTENT_ID, message.getContentId());
        cv.put(COLUMN_TEMPLATE, message.getTemplate());
        cv.put(COLUMN_CONTENT, message.getContent().toString());
        cv.put(COLUMN_ATTRIBUTION, message.getAttribution());
        cv.put(COLUMN_SEND_DATE, message.getSendDate().getTime());
        cv.put(COLUMN_EXPIRATION_DATE, message.getExpirationDate().getTime());
        cv.put(COLUMN_IS_DELETED, message.getIsDeleted());
        cv.put(COLUMN_IS_READ, message.getIsRead());
        return (getWritableDatabase().insert(TABLE_NAME, null, cv) != -1);
    }

    /**
     * Gets all non deleted messages
     * @return A cursor for all nessages
     */
    public MessageCursor getMessages()
    {
        return getMessages(COLUMN_IS_DELETED, "0");
    }

    /**
     * Gets a message by content id
     * @param contentId The content id
     * @return A cursor containing the message
     */
    public MessageCursor getMessagesByContentId(String contentId)
    {
        return getMessages(COLUMN_CONTENT_ID, contentId);
    }

    /**
     * Gets a message by message id
     * @param messageId The message id
     * @return A cursor containing the message
     */
    public MessageCursor getMessagesByMessageId(String messageId)
    {
        return getMessages(COLUMN_MESSAGE_ID, messageId);
    }

    MessageCursor getMessages(String field, String value)
    {
        String[] args = {value};
        Cursor wrapped = getReadableDatabase().query(TABLE_NAME, null, field + "=?", args, null, null,
                COLUMN_SEND_DATE + " asc");
        return new MessageCursor(wrapped);
    }

    /**
     * Set message as read
     * @param message The message
     * @return The number of messages updated
     */
    public int setMessageRead(RichContent message) {
        return setMessageReadById(message.getMessageId());
    }

    /**
     * Set message as read
     * @param messageId The message id
     * @return The number of messages updated
     */
    public int setMessageReadById(String messageId) {
        String[] args = {messageId};
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IS_READ, true);
        return getWritableDatabase().update(TABLE_NAME, cv, COLUMN_MESSAGE_ID + "=?", args);
    }

    /**
     * Set message as unread
     * @param message The message
     * @return The number of messages updated
     */
    public int setMessageUnread(RichContent message) {
        return setMessageUnreadById(message.getMessageId());
    }

    /**
     * Set message as unread
     * @param messageId The message id
     * @return The number of messages updated
     */
    public int setMessageUnreadById(String messageId) {
        String[] args = {messageId};
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IS_READ, false);
        return getWritableDatabase().update(TABLE_NAME, cv, COLUMN_MESSAGE_ID + "=?", args);
    }

    /**
     * Deletes all message marked as deleted
     */
    public void clearDeletedMessages() {
        String[] whereArgs =  { "0" };
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IS_DELETED, true);
        int deleted = getWritableDatabase().delete(TABLE_NAME, COLUMN_IS_DELETED + "!=?", whereArgs);


    }


    /**
     * This class is a cursor for inbox messages
     */
    public class MessageCursor extends CursorWrapper {

        private List<String> types = new ArrayList<String>();

        MessageCursor(Cursor cursor) {
            super(cursor);
        }

        /**
         * Retrieves the new inbox message
         * @return The message
         */
        public RichContent getRichContent()
        {

            RichContent message =  new RichContent();

            String messageId = getString(getColumnIndex(COLUMN_MESSAGE_ID));
            message.setMessageId(messageId);

            String contentId = getString(getColumnIndex(COLUMN_CONTENT_ID));
            message.setContentId(contentId);

            String template = getString(getColumnIndex(COLUMN_TEMPLATE));
            message.setTemplate(template);

            String attribution = getString(getColumnIndex(COLUMN_ATTRIBUTION));
            message.setAttribution(attribution);

            String contentString = getString(getColumnIndex(COLUMN_CONTENT));
            JSONObject content;
            try {
                content = new JSONObject(contentString);
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
            message.setContent(content);

            Long sendDateLong = getLong(getColumnIndex(COLUMN_SEND_DATE));
            Date sendDate = new Date(sendDateLong);
            message.setSendDate(sendDate);


            Long expirationDateLong = getLong(getColumnIndex(COLUMN_EXPIRATION_DATE));
            Date expirationDate = new Date(expirationDateLong);
            message.setExpirationDate(expirationDate);

            Boolean isDeleted = getInt(getColumnIndex(COLUMN_IS_DELETED))>0;
            message.setIsDeleted(isDeleted);

            Boolean isRead = getInt(getColumnIndex(COLUMN_IS_READ))>0;
            message.setIsRead(isRead);

            return message;
        }
    }


}

