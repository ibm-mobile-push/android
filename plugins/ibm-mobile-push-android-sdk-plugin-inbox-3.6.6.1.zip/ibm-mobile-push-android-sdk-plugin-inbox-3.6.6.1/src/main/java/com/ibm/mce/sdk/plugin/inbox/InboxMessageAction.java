/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.ibm.mce.sdk.api.OperationCallback;
import com.ibm.mce.sdk.api.OperationResult;
import com.ibm.mce.sdk.api.notification.MceNotificationAction;
import com.ibm.mce.sdk.api.notification.NotificationDetails;
import com.ibm.mce.sdk.notification.ActionImpl;
import com.ibm.mce.sdk.notification.NotificationsUtility;
import com.ibm.mce.sdk.util.Logger;
import com.ibm.mce.sdk.wi.AlarmScheduler;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * This class is the notification action that opens an inbox message
 */
public class InboxMessageAction implements MceNotificationAction {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    private static final String TAG = "InboxMessageAction";

    /**
     * This method handles the action call
     * @param context The application context
     * @param type The notification action type
     * @param name The notification action name (can be null)
     * @param attribution The notification attribution (can be null)
     * @param mailingId The notification mailing id
     * @param payload The notification payload. The map contains the key value pairs from the notification action payload.
     * @param fromNotification true if this action is called from a notification and false otherwise
     */
    @Override
    public void handleAction(Context context, String type, String name, String attribution, String mailingId, Map<String, String> payload, boolean fromNotification) {

        String contentId = payload.get("value");
        if (contentId != null) {
            RichContent message = InboxMessagesClient.getInboxMessageByContentId(context, contentId);
            if (message != null) {
                Intent it = new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
                context.sendBroadcast(it);
                Intent intent = new Intent(context, RichInboxActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("contentId", contentId);
                context.startActivity(intent);
                if(fromNotification) {
                    InboxEvents.sendInboxNotificationOpenedEvent(context, new ActionImpl(type, name, payload), attribution, mailingId);
                }
            }
        }


    }

    /**
     * This method initiates the action
     * @param context The application's context
     * @param initOptions The initialization options
     */
    @Override
    public void init(Context context, JSONObject initOptions) {
        new AlarmScheduler(context).schedule(new InboxUpdateService(), true, true);
        registerTemplates(initOptions);
    }

    /**
     * This method updates the action
     * @param context The application's context
     * @param updateOptions The update options
     */
    @Override
    public void update(Context context, JSONObject updateOptions) {
        registerTemplates(updateOptions);
    }

    /**
     * This method checks if inbox message is in the sdk db. If it's not, it returns false (which prevents the notification from appearing) and downloads the inbox message.
     * After the message is downloaded, the notification will be displayed
     * @param context The application's context
     * @param notificationDetails The received notification
     * @param sourceBundle The bundle that contained the notification
     * @return true if inbox message is in the db and false otherwise
     */
    @Override
    public boolean shouldDisplayNotification(final Context context, NotificationDetails notificationDetails, final Bundle sourceBundle) {
        final String contentId =notificationDetails.getAction().getPayloadValue("value");
        if(contentId != null) {
            boolean syncOccured = sourceBundle.getBoolean("inboxSyncOccured");
            if(syncOccured) {
                return true;
            }
            InboxMessagesClient.loadInboxMessages(context, new OperationCallback<List<RichContent>>() {
                @Override
                public void onSuccess(List<RichContent> richContents, OperationResult result) {
                    RichContent message = InboxMessagesClient.getInboxMessageByContentId(context, contentId);
                    if (message != null) {
                        try {
                            sourceBundle.putBoolean("inboxSyncOccured", true);
                            NotificationsUtility.showNotification(context, sourceBundle);
                        } catch (JSONException jsone) {
                            Logger.e(TAG, "Failed to show inbox message", jsone);
                        }
                    } else {
                        InboxMessagesClient.showNotificationWhenMessageArrives(contentId, sourceBundle);
                    }
                }

                @Override
                public void onFailure(List<RichContent> richContents, OperationResult result) {

                }
            });
        }
        return false;
    }

    private void registerTemplates(JSONObject options) {
        try {
            JSONObject templatesJSON = options.optJSONObject("templates");
            if(templatesJSON != null) {
                Iterator<String> templates = templatesJSON.keys();
                while(templates.hasNext()) {
                    String template = templates.next();
                    String templateClassName = templatesJSON.getString(template);
                    Class templateClass = Class.forName(templateClassName);
                    RichContentTemplate templateInstance = (RichContentTemplate)templateClass.newInstance();
                    RichContentTemplateRegistry.registerTemplate(template, templateInstance);
                }
            }
        } catch(Exception e) {
            Logger.e(TAG, "Failed to load templates", e);
        }
    }
}
