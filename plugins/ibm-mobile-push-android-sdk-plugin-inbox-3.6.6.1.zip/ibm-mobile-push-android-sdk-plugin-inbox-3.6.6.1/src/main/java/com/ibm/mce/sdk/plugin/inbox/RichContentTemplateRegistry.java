/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import java.util.HashMap;
import java.util.Map;

/**
 * This is the registry for inbox message templates
 */
public class RichContentTemplateRegistry {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    static final Map<String, RichContentTemplate> TEMPLATE_NAME_TO_TEMPLATE = new HashMap<String, RichContentTemplate>();

    static {
        registerTemplate("default", new HtmlRichContent());
        registerTemplate("post", new PostMessageTemplate());
    }

    /**
     * Registers a template
     * @param templateName The template name
     * @param template The template
     */
    public static void registerTemplate(String templateName, RichContentTemplate template) {
        TEMPLATE_NAME_TO_TEMPLATE.put(templateName, template);
    }

    /**
     * Retrieves a registered template
     * @param templateName The template name
     * @return The template
     */
    public static RichContentTemplate getRegisteredTemplate(String templateName) {

        RichContentTemplate template = TEMPLATE_NAME_TO_TEMPLATE.get(templateName);
        if(template == null) {
            template = new HtmlRichContent();
        }
        return template;
    }
}
