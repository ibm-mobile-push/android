/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * This class is the preview implementation of the html template
 */
public class HtmlInboxMessagePreviewFragment implements InboxMessagePreviewFragment {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    /**
     * This method generates a new preview view
     * @param adapter The messages adapter
     * @param context The application context
     * @param cursor The messages cursor
     * @param parent The fragment parent
     * @return The new view
     */
    @Override
    public View newView(CursorAdapter adapter, Context context, Cursor cursor, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(context.getResources().getIdentifier("list_item_rich_inbox", "layout", context.getPackageName()), parent, false);

        ViewHolder holder = new ViewHolder();
        holder.setChevronView((ImageView) rowView.findViewById(context.getResources().getIdentifier("chevron", "id", context.getPackageName())));
        holder.setSubjectView((TextView) rowView.findViewById(context.getResources().getIdentifier("subject", "id", context.getPackageName())));
        holder.setPreviewView((TextView) rowView.findViewById(context.getResources().getIdentifier("preview", "id", context.getPackageName())));
        holder.setDateView((TextView) rowView.findViewById(context.getResources().getIdentifier("date", "id", context.getPackageName())));
        rowView.setTag(holder);

        return rowView;
    }

    /**
     * This method display an html message preview in the fragment
     * @param adapter The messages adapter
     * @param view The containing view
     * @param context The application context
     * @param cursor The messages cursor
     */
    @Override
    public void bindView(CursorAdapter adapter, View view, Context context, Cursor cursor) {
        RichInboxListFragment.MessageCursorAdapter messageCursorAdapter = (RichInboxListFragment.MessageCursorAdapter)adapter;
        ViewHolder holder = (ViewHolder) view.getTag();

        RichContent message = holder.getMessage();
        if(message==null)
        {
            message = messageCursorAdapter.getMessageCursor().getRichContent();
            holder.setMessage(message);
        }

        // Read/unread status
        int color = context.getResources().getColor(android.R.color.primary_text_dark);
        Typeface typeface = Typeface.defaultFromStyle(Typeface.BOLD);
        if(message.getIsRead()) {
            typeface = Typeface.defaultFromStyle(Typeface.NORMAL);
            color = context.getResources().getColor(android.R.color.secondary_text_light);
        }
        if(message.getIsExpired()) {
            typeface = Typeface.defaultFromStyle(Typeface.NORMAL);
            color = context.getResources().getColor(android.R.color.secondary_text_dark);
        }

        TextView dateView = holder.getDateView();
        Date send = message.getSendDate();       
        SimpleDateFormat format = new SimpleDateFormat("M/d/yy");
        CharSequence dateString = format.format(send);
        dateView.setText(dateString);
        dateView.setTextColor(color);
        dateView.setTypeface(typeface);

        if(messageCursorAdapter.isTablet()) {
            // tablet interface

            // Selected message status blue color
            int currentIndex = messageCursorAdapter.getRichInboxFragment().getCurrentIndex();

            ImageView chevronView = holder.getChevronView();
            if (currentIndex != -1 && cursor.getPosition() == currentIndex) {
                chevronView.setImageResource(context.getResources().getIdentifier("highlight_chevron", "drawable", context.getPackageName()));
                color = Color.argb(255, 165, 220, 255);
            } else {
                chevronView.setImageResource(context.getResources().getIdentifier("chevron", "drawable", context.getPackageName()));
            }
        }

        TextView subjectView = holder.getSubjectView();
        subjectView.setText(message.getSubject());
        subjectView.setTypeface(typeface);
        subjectView.setTextColor(color);

        TextView previewView = holder.getPreviewView();
        previewView.setText(message.getPreview());
    }

    /**
     * This method is called when the view is hiiden
     * @param message The view message
     * @param activityId The containing activity id
     */
    @Override
    public void viewHidden(RichContent message, long activityId) {

    }

    private class ViewHolder
    {
        TextView dateView;
        TextView previewView;
        TextView subjectView;
        ImageView chevronView;

        public RichContent getMessage() {
            return message;
        }

        public void setMessage(RichContent message) {
            this.message = message;
        }

        RichContent message;

        public TextView getDateView() {
            return dateView;
        }

        public void setDateView(TextView dateView) {
            this.dateView = dateView;
        }

        public TextView getPreviewView() {
            return previewView;
        }

        public void setPreviewView(TextView previewView) {
            this.previewView = previewView;
        }

        public TextView getSubjectView() {
            return subjectView;
        }

        public void setSubjectView(TextView subjectView) {
            this.subjectView = subjectView;
        }

        public ImageView getChevronView() {
            return chevronView;
        }

        public void setChevronView(ImageView chevronView) {
            this.chevronView = chevronView;
        }
    }

}
