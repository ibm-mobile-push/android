/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;

/**
 * This is the inbox activity class
 */
public class RichInboxActivity extends Activity {
    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    private long id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        updateId(savedInstanceState);

        setContentView(getResources().getIdentifier("rich_inbox_activity", "layout", getPackageName()));
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        updateId(savedInstanceState);
    }

    /**
     * Called when the activity is restored
     * @param savedInstanceState The activity's saved state
     * @param persistentState The persistent sttate
     */
    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onRestoreInstanceState(savedInstanceState, persistentState);
        updateId(savedInstanceState);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        storeId(outState);
    }

    /**
     * Called when the activity state is saved
     * @param outState The activity state
     * @param outPersistentState The persistent state
     */
    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        storeId(outState);
    }

    /**
     * Retrieves the activity's id
     * @return The id
     */
    public long getId() {
        return id;
    }

    private void updateId(Bundle savedInstanceState) {
        if(savedInstanceState == null || !savedInstanceState.containsKey("inboxActivityId")) {
            id = System.currentTimeMillis();
        } else {
            id = savedInstanceState.getLong("inboxActivityId");
        }
    }

    private void storeId(Bundle outState) {
        outState.putLong("inboxActivityId", id);
    }
}