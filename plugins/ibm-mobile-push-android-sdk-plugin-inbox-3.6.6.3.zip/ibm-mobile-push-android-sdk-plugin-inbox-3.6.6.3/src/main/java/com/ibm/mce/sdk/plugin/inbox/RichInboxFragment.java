/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

import android.app.ActionBar;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.widget.SlidingPaneLayout;
import android.view.*;

/**
 * This class is the inbox fragment
 */
public class RichInboxFragment extends Fragment {
    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";

    private static final String TAG = "RichInboxFragment";
    private ViewGroup viewGroup;
    private int currentIndex = 0;

    int getCurrentIndex()
    {
        return currentIndex;
    }

    /**
     * Sets the fragment's view group
     * @param viewGroup The view group
     */
    public void setViewGroup(ViewGroup viewGroup) {
        viewGroup = viewGroup;
    }

    /**
     * Sets the inbox current indez
     * @param currentIndex The current index
     */
    public void setCurrentIndex(int currentIndex) {
        this.currentIndex = currentIndex;

    }

    /**
     * Called when the fragment is created.
     * @param savedInstanceState The saved fragment state
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(newMessageReceiver,
                new IntentFilter("MPNewMessage"));
    }

    private BroadcastReceiver newMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            RichInboxListFragment richInboxListFragment = (RichInboxListFragment) getFragmentManager().findFragmentById(getResources().getIdentifier("rich_inbox_list", "id", getView().getContext().getPackageName()));
            if(richInboxListFragment==null) {
                int count = intent.getIntExtra("count", 0);
                if(count < 5) {
                    Intent retryIntent = new Intent("MPNewMessage");
                    retryIntent.putExtra("count", count+1);
                    LocalBroadcastManager.getInstance(getActivity()).sendBroadcast(retryIntent);
                    return;
                }
            }
            richInboxListFragment.restartLoader();
            getActivity().invalidateOptionsMenu();
        }
    };

    /**
     * Called when the fragment view is created
     * @param inflater The layout inflater
     * @param container The view's container
     * @param savedInstanceState The saved view state
     * @return The new fragment view
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        super.onCreateView(inflater, container, savedInstanceState);
        int fragmentLayoutId = getResources().getIdentifier("rich_inbox_fragment", "layout", inflater.getContext().getApplicationContext().getPackageName());
        int inboxLayoutId = getResources().getIdentifier("rich_inbox_layout", "id", inflater.getContext().getApplicationContext().getPackageName());

        ActionBar actionBar = getActivity().getActionBar();
        if(actionBar != null)
            actionBar.setHomeButtonEnabled(true);

        View view = inflater.inflate(fragmentLayoutId, container, false);
        setViewGroup((ViewGroup) view.findViewById(inboxLayoutId));
        setHasOptionsMenu(true);

        return view;
    }

    /**
     * Displays the fragment
     * @param fragmentManager
     */
    public void showContent(FragmentManager fragmentManager)
    {
        RichInboxListFragment richInboxListFragment = (RichInboxListFragment)fragmentManager.findFragmentById(getResources().getIdentifier("rich_inbox_list", "id", getView().getContext().getPackageName()));

        RichContent message = richInboxListFragment.getMessage(getCurrentIndex());
        if(message==null)
            return;



        Configuration config = getActivity().getResources().getConfiguration();
        if(config.isLayoutSizeAtLeast(Configuration.SCREENLAYOUT_SIZE_LARGE)) {
            // tablet interface
            richInboxListFragment.notifyDataSetChanged();
        }
        else
        {
            // phone interface
            setActionBarUp(true);
        }

        getActivity().invalidateOptionsMenu();
    }

    /**
     * Called when preparing the menu is needed
     * @param menu
     */
    @Override
    public void onPrepareOptionsMenu (Menu menu) {

    }

    /**
     * Called when the fragment starts
     */
    @Override
    public void onStart() {
        super.onStart();
    }

    /**
     * Sets the action bar state
     * @param setting true for up, false for down
     */
    public void setActionBarUp(boolean setting)
    {
        ActionBar actionBar = getActivity().getActionBar();
        if(actionBar != null)
            actionBar.setDisplayHomeAsUpEnabled(setting);
    }


    /**
     * Called when the menu is created
     * @param menu The menu
     * @param inflater The layout inflater
     */
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
    }

    /**
     * Called when menu option is selected
     * @param item The selected item
     * @return true for operation is done, false otherwise
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return true;
    }





}
