/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2016.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;


import android.app.Activity;
import android.content.Context;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ibm.mce.sdk.api.MediaManager;
import com.ibm.mce.sdk.api.notification.Action;
import com.ibm.mce.sdk.api.notification.MceNotificationAction;
import com.ibm.mce.sdk.api.notification.MceNotificationActionRegistry;
import com.ibm.mce.sdk.notification.ActionImpl;
import com.ibm.mce.sdk.util.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * This is the implementation of the post template
 */
public class PostMessageTemplate implements RichContentTemplate {




    private static final String TAG = "PostMessageTemplate";

    private static final Map<Long, Map<String, VideoController>> ACTIVITY_ID_TO_VIDEO_CACHE = new HashMap<Long, Map<String, VideoController>>();
    private static VideoController currentlyPlaying;



    private static void setVideoController(long activityId, String url, TextureView videoView, ImageView videoLayover, Context context) {
        synchronized (ACTIVITY_ID_TO_VIDEO_CACHE) {
            Map<String, VideoController> videoCache = null;
            if(activityId > 0) {
                videoCache = ACTIVITY_ID_TO_VIDEO_CACHE.get(activityId);
                if (videoCache == null) {
                    ACTIVITY_ID_TO_VIDEO_CACHE.clear();
                    videoCache = new HashMap<String, VideoController>();
                    ACTIVITY_ID_TO_VIDEO_CACHE.put(activityId, videoCache);
                }
            } else{
                if(ACTIVITY_ID_TO_VIDEO_CACHE.values().isEmpty()) {
                    videoCache = ACTIVITY_ID_TO_VIDEO_CACHE.values().iterator().next();
                }
            }
            if(videoCache != null) {
                VideoController controller = videoCache.get(url);
                if (controller == null) {
                    VideoController controler = new VideoController(url, videoView, videoLayover, context);
                    videoCache.put(url, controler);
                } else {
                    controller.updateVideoView(videoView, videoLayover, context);
                }
            }
        }
    }

    /**
     * Retrieves the relevant preview fragment implementation
     * @return The post preview fragment implementation
     */
    @Override
    public InboxMessagePreviewFragment getPreviewFragment() {
        return new PostMessagePreviewFragment();
    }

    /**
     * Retrieves the relevant message display implementation
     * @return The post message display implementation
     */
    @Override
    public InboxMessageDisplay getInboxMessageDisplay() {
        return new PostInboxMessageDisplay();
    }

    public static void updateHeaderView(Context context, Activity activity, View view, PostMessage postMessage) {
        TextView headerTitleView =(TextView) view.findViewById(context.getResources().getIdentifier("headerTitle", "id", context.getPackageName()));
        TextView subHeaderView = (TextView) view.findViewById(context.getResources().getIdentifier("subHeader", "id", context.getPackageName()));

        headerTitleView.setText(postMessage.getHeader());
        subHeaderView.setText(postMessage.getSubHeader());
        if(postMessage.getHeaderImage() != null) {
            ImageView headerIconView = (ImageView) view.findViewById(context.getResources().getIdentifier("headerIcon", "id", context.getPackageName()));
            headerIconView.setVisibility(View.VISIBLE);
            MediaManager.setImage(postMessage.getHeaderImage(), headerIconView, activity);
        }
    }

    static TextView updateContentTextView(Context context, View view, PostMessage postMessage) {
        if(postMessage.getContentText() != null) {
            TextView textView =(TextView) view.findViewById(context.getResources().getIdentifier("text", "id", context.getPackageName()));
            textView.setText(postMessage.getContentText());
            textView.setVisibility(View.VISIBLE);
            return textView;
        } else {
            return null;
        }
    }

    static boolean updateContentImageView(Context context, Activity activity, View view, PostMessage postMessage) {
        if(postMessage.getContentImage() != null) {
            ImageView imageView = (ImageView) view.findViewById(context.getResources().getIdentifier("img", "id", context.getPackageName()));
            MediaManager.setImage(postMessage.getContentImage(), imageView, activity);
            imageView.setVisibility(View.VISIBLE);
            return true;
        } else {
            return false;
        }
    }

    static RelativeLayout updateContentVideoView(Context context, Activity activity, View view, PostMessage postMessage) {
        return updateContentVideoView(context, ((RichInboxActivity)activity).getId(), view, postMessage);
    }

    static RelativeLayout updateContentVideoView(Context context, long activityId, View view, PostMessage postMessage) {
        if(activityId > 0 && postMessage.getContentVideo() != null && postMessage.getContentImage() == null) {
            final TextureView videoView = (TextureView) view.findViewById(context.getResources().getIdentifier("video", "id", context.getPackageName()));
            final ImageView videoOverlay = (ImageView) view.findViewById(context.getResources().getIdentifier("videoOverlay", "id", context.getPackageName()));
            final RelativeLayout videoLayout = (RelativeLayout) view.findViewById(context.getResources().getIdentifier("videoLayout", "id", context.getPackageName()));

            final String videoUrl = postMessage.getContentVideo();
            videoView.setVisibility(View.VISIBLE);
            videoLayout.setVisibility(View.VISIBLE);
            setVideoController(activityId, videoUrl, videoView, videoOverlay, context);
            return videoLayout;
        } else {
            return null;
        }
    }

    static boolean updateButtons(Context context, View view, PostMessage postMessage, RichContent originalMessage ) {
        Action[] actions = postMessage.getActions();
        if(actions != null && actions.length > 0) {
            LinearLayout buttonsLayout = (LinearLayout) view.findViewById(context.getResources().getIdentifier("buttons", "id", context.getPackageName()));
            Button[] buttons = new Button[]{
                    (Button) view.findViewById(context.getResources().getIdentifier("button1", "id", context.getPackageName())),
                    (Button) view.findViewById(context.getResources().getIdentifier("button2", "id", context.getPackageName())),
                    (Button) view.findViewById(context.getResources().getIdentifier("button3", "id", context.getPackageName()))
            };

            buttonsLayout.setVisibility(View.VISIBLE);
            for (int i = 0; i < buttons.length; ++i) {
                if (i < actions.length) {
                    PostMessageTemplate.setActionToButton(buttons[i], actions[i], originalMessage);
                } else {
                    buttons[i].setVisibility(View.GONE);
                }
            }
            return true;
        } else {
            return false;
        }
    }

    private static Action getAction(JSONObject actionJSON) {
        try {
            String type = actionJSON.getString("type");
            String name = actionJSON.optString("name", "");
            String value = actionJSON.get("value").toString();
            Map<String, String> payload = new HashMap<String, String>();
            payload.put("value", value);
            Iterator<String> keys = actionJSON.keys();
            while(keys.hasNext()) {
                String key = keys.next();
                if(!"type".equals(key) && !"name".equals(key) && !"value".equals(key)) {
                    payload.put(key, actionJSON.get(key).toString());
                }
            }
            Action action = new ActionImpl(type, name, payload);
            return action;
        } catch(JSONException e) {
            return null;
        }
    }

    private static void setActionToButton(Button button, final Action action, final RichContent message) {
        button.setText(action.getName());
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MceNotificationAction actionImpl = MceNotificationActionRegistry.getNotificationAction(action.getType());
                if (actionImpl != null) {
                    Map<String, String> payload = new HashMap<String, String>();
                    for (String key : action.getPayloadKeys()) {
                        payload.put(key, action.getPayloadValue(key));
                    }
                    actionImpl.handleAction(v.getContext().getApplicationContext(), action.getType(), action.getType(), message.getAttribution(), null, payload, false);
                    InboxEvents.sendInboxMessageActionTakenEvent(v.getContext().getApplicationContext(), message, action);
                }
            }
        });
    }

    static void setHidden(String videoUrl, long activityId) {
        synchronized (ACTIVITY_ID_TO_VIDEO_CACHE) {
            Map<String, VideoController> videoCache = null;
            videoCache = ACTIVITY_ID_TO_VIDEO_CACHE.get(activityId);
            if(videoCache != null) {
                VideoController controller = videoCache.get(videoUrl);
                if (controller != null) {
                    controller.pause();
                }
            }
        }
    }

    static class PostMessage {
        private String header;
        private String subHeader;
        private String headerImage;
        private String contentText;
        private String contentImage;
        private String contentVideo;
        private Action[] actions;

        public PostMessage(RichContent richContent) throws JSONException {
            JSONObject content = richContent.getContent();
            if(content == null) {
                throw new JSONException("No content was found");
            }
            header = content.getString("header");
            subHeader = content.optString("subHeader", "");
            headerImage = content.optString("headerImage", null);
            contentText = content.optString("contentText", null);
            contentImage = content.optString("contentImage", null);
            contentVideo = content.optString("contentVideo", null);
            JSONArray actiobsJSONArray = content.optJSONArray("actions");
            if(actiobsJSONArray == null) {
                actions = null;
            } else {
                actions = new Action[actiobsJSONArray.length()];
                for(int i=0 ; i<actiobsJSONArray.length() ; ++i) {
                    actions[i] = getAction(actiobsJSONArray.getJSONObject(i));
                }
            }
        }

        public String getHeader() {
            return header;
        }

        public String getSubHeader() {
            return subHeader;
        }

        public String getHeaderImage() {
            return headerImage;
        }

        public String getContentText() {
            return contentText;
        }

        public String getContentImage() {
            return contentImage;
        }

        public String getContentVideo() {
            return contentVideo;
        }

        public Action[] getActions() {
            return actions;
        }
    }

    static class VideoController implements MediaPlayer.OnPreparedListener, MediaPlayer.OnCompletionListener,
            MediaPlayer.OnInfoListener, MediaPlayer.OnSeekCompleteListener, MediaPlayer.OnErrorListener,
            MediaPlayer.OnVideoSizeChangedListener, TextureView.SurfaceTextureListener, TextureView.OnClickListener,
            MediaController.MediaPlayerControl, MediaPlayer.OnBufferingUpdateListener {

        private String videoUrl;
        private MediaPlayer mediaPlayer;
        private TextureView videoView;
        private ImageView videoOverlay;
        private Context context;
        private boolean mediaPlayerPrepared;
        private boolean mediaPlayerPreparing;
        private boolean surfacePrepared;
        private boolean playing;
        private int bufferPercent;


        public VideoController(String videoUrl,  TextureView videoView, ImageView videoOverlay, Context context){
            Logger.d(TAG,"VIDEOLIFECYCLE - Video controller created: "+videoUrl);
            this.videoUrl = videoUrl;
            this.videoOverlay = videoOverlay;
            this.context = context;
            this.videoView = videoView;
            this.mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.setDataSource(videoUrl);
                mediaPlayer.setOnPreparedListener(this);
                mediaPlayer.setOnSeekCompleteListener(this);
                mediaPlayer.setOnCompletionListener(this);
                mediaPlayer.setOnVideoSizeChangedListener(this);
                mediaPlayer.setOnInfoListener(this);
                mediaPlayer.setOnBufferingUpdateListener(this);
            } catch (IOException ioe) {
                Logger.e(TAG, "Failed to load video " + videoUrl, ioe);
            }
            /*
            MediaController controller = new MediaController(context);
            controller.setMediaPlayer(this);
            controller.setAnchorView(videoView);
            controller.setEnabled(true);
            */
            //mediaPlayer.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);

            prepare();
        }

        public void updateVideoView(TextureView videoView, ImageView videoOverlay, Context context) {
            this.context = context;
            this.videoOverlay = videoOverlay;
            if(this.videoView != null && this.videoView != videoView) {
                this.videoView.setSurfaceTextureListener(null);
                this.videoView.setOnClickListener(null);
                this.videoView = videoView;
                surfacePrepared = false;
                prepare();
            } else {
                setReadyToPlay();
            }
        }

        @Override
        public void onCompletion(MediaPlayer mp) {
            playing = false;
            videoOverlay.setImageResource(context.getResources().getIdentifier("ic_mce_video_wait", "drawable", context.getPackageName()));
            videoOverlay.setVisibility(View.VISIBLE);
            videoView.setOnClickListener(null);
            mediaPlayer.seekTo(0);
        }

        @Override
        public boolean onInfo(MediaPlayer mp, int what, int extra) {
            return false;
        }

        @Override
        public void onPrepared(MediaPlayer mp) {
            mediaPlayerPrepared = true;
            mediaPlayerPreparing = false;
            setReadyToPlay();
        }

        @Override
        public void onSeekComplete(MediaPlayer mp) {
            if(!playing) {
                setReadyToPlay();
                videoView.setOnClickListener(this);
            }
        }

        @Override
        public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
        }

        @Override
        public boolean onError(MediaPlayer mp, int what, int extra) {
            Logger.e(TAG, "Video error for " + videoUrl + ": " + what + ", " + extra);
            return false;
        }

        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            surfacePrepared = true;
            mediaPlayer.setSurface(new Surface(surface));
            if(!mediaPlayerPrepared && !mediaPlayerPreparing) {
                try {
                    mediaPlayerPreparing = true;
                    mediaPlayer.prepareAsync();
                } catch (IllegalStateException ise) {
                    //prevent a crash if and when timing is wrong
                    Logger.e(TAG,"Error while preparing video", ise);
                }

            } else {
                setReadyToPlay();
            }
            //mediaPlayer.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);



        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {

        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {

        }

        @Override
        public void onBufferingUpdate(MediaPlayer mp, int percent) {
            bufferPercent = percent;
        }

        @Override
        public void onClick(View v) {
            if(!playing) {
                play();
            } else {
               pause();
            }
        }

        public void pause() {
            if (mediaPlayer.isPlaying()) {
                videoOverlay.setVisibility(View.VISIBLE);
                mediaPlayer.pause();
                playing = false;
                videoOverlay.setImageResource(context.getResources().getIdentifier("ic_mce_video_play", "drawable", context.getPackageName()));
            }
        }

        @Override
        public void start() {
            mediaPlayer.start();
        }

        @Override
        public int getDuration() {
            return mediaPlayer.getDuration();
        }

        @Override
        public int getCurrentPosition() {
            return mediaPlayer.getCurrentPosition();
        }

        @Override
        public void seekTo(int pos) {
            mediaPlayer.seekTo(pos);
        }

        @Override
        public boolean isPlaying() {
            return mediaPlayer.isPlaying();
        }

        @Override
        public int getBufferPercentage() {
            return bufferPercent;
        }

        @Override
        public boolean canPause() {
            return mediaPlayer.isPlaying();
        }

        @Override
        public boolean canSeekBackward() {
            return true;
        }

        @Override
        public boolean canSeekForward() {
            return true;
        }

        @Override
        public int getAudioSessionId() {
            return mediaPlayer.getAudioSessionId();
        }

        public void play() {
            if(currentlyPlaying != null) {
                currentlyPlaying.pause();
            }
            videoOverlay.setVisibility(View.INVISIBLE);
            mediaPlayer.start();
            playing = true;
            currentlyPlaying = this;
        }

        public void prepare() {
            videoOverlay.setImageResource(context.getResources().getIdentifier("ic_mce_video_wait", "drawable", context.getPackageName()));
            this.videoView.setSurfaceTextureListener(this);
        }

        private void setReadyToPlay() {
            videoOverlay.setImageResource(context.getResources().getIdentifier("ic_mce_video_play", "drawable", context.getPackageName()));
            videoView.setOnClickListener(this);
        }
    }




}
