/*
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise? divested of its trade secrets, irrespective of what has been? deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.inbox;

/**
 * This is the implementation of the html template
 */
public class HtmlRichContent implements RichContentTemplate {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";


    /**
     * Retrieves the relevant preview fragment implementation
     * @return The html preview fragment implementation
     */
    @Override
    public InboxMessagePreviewFragment getPreviewFragment() {
        return new HtmlInboxMessagePreviewFragment();
    }

    /**
     * Retrieves the relevant message display implementation
     * @return The html message display implementation
     */
    @Override
    public InboxMessageDisplay getInboxMessageDisplay() {
        return new HtmlInboxMessageDisplay();
    }
}
