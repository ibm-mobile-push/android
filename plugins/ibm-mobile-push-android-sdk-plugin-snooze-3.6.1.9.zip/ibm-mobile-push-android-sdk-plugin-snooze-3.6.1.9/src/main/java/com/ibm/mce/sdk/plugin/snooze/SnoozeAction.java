/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */
package com.ibm.mce.sdk.plugin.snooze;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.ibm.mce.sdk.api.Constants;
import com.ibm.mce.sdk.api.notification.MceNotificationAction;
import com.ibm.mce.sdk.api.notification.NotificationDetails;
import com.ibm.mce.sdk.util.Logger;

import org.json.JSONObject;

import java.util.Map;

/**
 * This class is an MCE notification action implementation that snoozes a notification for a given amount of minutes. The event has one property - time, which is the
 * number of minutest the notification will snooze for.
 * When the action is clicked, the notification will disappear from the notification bar and reappear after the given number of minutes.
 */
public class SnoozeAction implements MceNotificationAction {

    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";
    private static final String TAG = "SnoozeAction";

    /**
     * The "time" property key.
     */
    public static final String TIME_KEY = "time";

    /**
     * This method implements the "snnoze" action.
     * @param context The application context
     * @param type The notification action type
     * @param name The notification action name (can be null)
     * @param attribution The notification attribution (can be null)
     * @param payload The notification payload. The map contains the time value.
     */
    @Override
    public void handleAction(Context context, String type, String name, String attribution, Map<String, String> payload, boolean fromNotification) {

        int notifId =  Integer.parseInt(payload.get(Constants.Notifications.SOURCE_NOTIF_ID_KEY));
        int delayInMinutes = Integer.parseInt(payload.get(TIME_KEY));
        Logger.d(TAG, "Source Delay: " + delayInMinutes);
        AlarmManager mgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent =  new Intent(context, SnoozeIntentService.class);
        intent.putExtra(Constants.Notifications.SOURCE_NOTIFICATION_KEY, payload.get(Constants.Notifications.SOURCE_NOTIFICATION_KEY));
        intent.putExtra(Constants.Notifications.SOURCE_MCE_PAYLOAD_KEY, payload.get(Constants.Notifications.SOURCE_MCE_PAYLOAD_KEY));
        PendingIntent pi = PendingIntent.getService(context, 0, intent, 0);
        (new SnoozeIntentService()).scheduleSnooze(mgr, pi, delayInMinutes);
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(notifId);

    }

    @Override
    public void init(Context context, JSONObject initOptions) {

    }

    @Override
    public void update(Context context, JSONObject updateOptions) {

    }

    @Override
    public boolean shouldDisplayNotification(Context context, NotificationDetails notificationDetails, Bundle sourceBundle) {
        return true;
    }
}
