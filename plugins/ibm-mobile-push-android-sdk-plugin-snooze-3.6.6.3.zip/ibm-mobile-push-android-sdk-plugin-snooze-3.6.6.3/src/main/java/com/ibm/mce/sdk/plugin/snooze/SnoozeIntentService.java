/*
 * IBM Confidential
 * OCO Source Materials
 * 5725E28, 5725S01, 5725I03
 * © Copyright IBM Corp. 2011, 2015.
 * The source code for this program is not published or otherwise  divested of its trade secrets, irrespective of what has been  deposited with the U.S. Copyright Office.
 */

package com.ibm.mce.sdk.plugin.snooze;

import android.app.AlarmManager;
import android.app.IntentService;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;

import com.ibm.mce.sdk.api.Constants;
import com.ibm.mce.sdk.notification.NotificationsUtility;
import com.ibm.mce.sdk.util.Logger;

import org.json.JSONException;

import java.util.Calendar;

/**
 * This service restores the snoozed notification to the notification bar.
 */
public class SnoozeIntentService extends IntentService {
    public static final String COPYRIGHT=
            "\n\nLicensed Materials - Property of IBM\n5725E28, 5725S01, 5725I03\n© Copyright IBM Corp. 2015, ${YEAR}.\nUS Government Users Restricted Rights - Use, duplication or disclosure\nrestricted by GSA ADP Schedule Contract with IBM Corp.\n\n";
    private static final String TAG = "SnoozeIntentService";

    public SnoozeIntentService() {
        super("Snooze");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Logger.d(TAG, "Snooze done");
        Bundle extras = new Bundle();
        extras.putString(Constants.Notifications.ALERT_KEY, intent.getStringExtra(Constants.Notifications.SOURCE_NOTIFICATION_KEY));
        extras.putString(Constants.Notifications.MCE_PAYLOAD_KEY, intent.getStringExtra(Constants.Notifications.SOURCE_MCE_PAYLOAD_KEY));
        try {
            NotificationsUtility.showNotification(getApplicationContext(), extras, 0, null);
        } catch (JSONException jsone) {
            Logger.e(TAG, "Failed to parse notification", jsone);
        }
    }


    /**
     * This method schedule a notification reappearance
     * @param mgr The alarm manager
     * @param pi The pending intent for the action
     * @param delayInMinutes The number of minutes after which the notification will reappear
     */
    public void scheduleSnooze(AlarmManager mgr, PendingIntent pi, int delayInMinutes) {
        Calendar alertTime = Calendar.getInstance();
        alertTime.setTimeInMillis(System.currentTimeMillis());
        alertTime.add(Calendar.MINUTE, delayInMinutes);
        mgr.set(AlarmManager.RTC, alertTime.getTimeInMillis(), pi);
        Logger.d(TAG, "Snooze service was scheduled with the date " + alertTime.getTime());
    }
}
