package com.ibm.wca.samples.android;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.support.v4.app.NotificationCompat;

public class ForegroundService extends Service {
    private static final String LOG_TAG = "ForegroundService";
    static final String START_ACTION = "FOREGROUND_START_ACTION";
    static final String STOP_ACTION = "FOREGROUND_STOP_ACTION";
    static final String MAIN_ACTION = "FOREGROUND_MAIN_ACTION";

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(LOG_TAG, "onStartCommand");
        String action = intent.getAction();
        if(action == null) {
            return START_STICKY;
        }
        if (action.equals(START_ACTION)) {
            Log.i(LOG_TAG, "Received Start Foreground Intent ");
            Intent notificationIntent = new Intent(this, MainSampleMenuActivity.class);
            notificationIntent.setAction(MAIN_ACTION);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                    notificationIntent, 0);

            Notification notification = new NotificationCompat.Builder(this, SampleApplication.MCE_SERVICE_CHANNEL_ID)
                    .setContentTitle("(your application name)")
                    .setContentText("Listening for geofences/beacons...")
                    .setSmallIcon(R.drawable.ic_launcher)
                    .setContentIntent(pendingIntent)
                    .setOngoing(true)
                    .build();
            startForeground(1, notification);
        }
        if (action.equals(STOP_ACTION)) {
            Log.i(LOG_TAG, "Received Stop Foreground Intent");
            stopForeground(true);
            stopSelf();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        // Used only in case of bound services.
        return null;
    }
}
